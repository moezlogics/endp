import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Killing of Polio Workers and Security Personnel is Deplorable",
  description: "This statement addresses a serious security incident affecting polio vaccination teams in Pakistan — the men and women who risk their safety to protect chi...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/223-killing-of-polio-workers-and-security-personnel-is-deplorable",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This statement addresses a serious security incident affecting polio vaccination teams in Pakistan — the men and women who risk their safety to protect children from a devastating, preventable disease. Attacks on health workers represent an assault on the fundamental right of every child to receive life-saving vaccination.</p>

<h2>Context &amp; Programme Response</h2>
<p>Pakistan's polio vaccination programme deploys over 350,000 frontline workers during each national campaign, making it one of the largest peacetime mobilizations in the world. These workers — predominantly women — travel door to door in every neighborhood and village, carrying vaccine carriers and going wherever children live. In some areas, they face genuine security threats that make their already challenging work dangerous.</p>
<p>Since the polio eradication programme began, Pakistan has lost dozens of dedicated health workers to violence. Each loss is a tragedy that reverberates through the programme and through the communities these workers served. The government has responded by strengthening security protocols, deploying protective escorts in high-risk areas, and working with law enforcement to ensure the safety of vaccination teams.</p>

<h2>Commitment to Eradication Despite Challenges</h2>
<p>Despite these challenges, Pakistan's commitment to polio eradication remains unwavering. The overwhelming majority of communities welcome vaccination teams warmly, understanding that the workers are there to protect their children. Community leaders, religious scholars, and local officials play a crucial role in ensuring the safety and acceptance of vaccination teams.</p>
<p>The programme continues to innovate its security arrangements, working closely with military and civilian law enforcement agencies to develop context-specific safety protocols. The goal is to ensure that every child, everywhere in Pakistan, can be reached with the polio vaccine — safely and without interruption.</p>
<p>The international community has repeatedly condemned violence against health workers and called for their protection under international humanitarian law. Every attack that prevents vaccination leaves children vulnerable to a disease that can cause irreversible paralysis.</p>`

  return (
    <PolioInfoPage
      title="Killing of Polio Workers and Security Personnel is Deplorable"
      path="/media-room/media-releases/223-killing-of-polio-workers-and-security-personnel-is-deplorable"
      contentHtml={content}
      metrics={[
        { label: "Workers Deployed", value: "350,000+" },
        { label: "Response", value: "Security Protocol" },
        { label: "Priority", value: "Worker Safety" },
        { label: "Commitment", value: "Unwavering" }
      ]}
    />
  )
}
