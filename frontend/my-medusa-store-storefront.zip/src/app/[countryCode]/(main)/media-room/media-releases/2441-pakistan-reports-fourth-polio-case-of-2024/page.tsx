import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Pakistan Reports Fourth Polio Case of 2024",
  description: "This press release reports that Pakistan has confirmed its fourth case of polio in 2024. The announcement underscores the continued presence of poliovirus...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2441-pakistan-reports-fourth-polio-case-of-2024",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release reports that Pakistan has confirmed its fourth case of polio in 2024. The announcement underscores the continued presence of poliovirus in the country and the urgent need for sustained vaccination efforts to protect children from paralysis.</p>

<h2>Key Information</h2>
<p>Polio Case in Pakistan: A new case of polio has been confirmed in Pakistan, bringing the total for the year to four.</p>
<p>Public Health Concern: The case highlights the ongoing risk of poliovirus circulation and the importance of continued vaccination efforts.</p>
<p>Geographical Context: The report places the case within the broader polio eradication efforts in Pakistan, emphasizing the need for targeted interventions in high-risk areas.</p>
<p>This information is crucial for stakeholders involved in polio eradication, as it underscores the need for continued vigilance and intensified vaccination campaigns to protect children from the devastating effects of polio.</p>`

  return (
    <PolioInfoPage
      title="Pakistan Reports Fourth Polio Case of 2024"
      path="/media-room/media-releases/2441-pakistan-reports-fourth-polio-case-of-2024"
      contentHtml={content}
      metrics={[
        { label: "Case Number", value: "Confirmed" },
        { label: "Year", value: "2024" },
        { label: "Virus Type", value: "WPV1" },
        { label: "Response", value: "Outbreak Protocol" }
      ]}
    />
  )
}
