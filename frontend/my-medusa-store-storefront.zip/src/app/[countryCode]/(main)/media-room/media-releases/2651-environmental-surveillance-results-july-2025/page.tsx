import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Environmental Surveillance Results – July 2025",
  description: "Environmental surveillance is Pakistan's early warning system for poliovirus detection. By testing sewage and wastewater samples from designated collection...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2651-environmental-surveillance-results-july-2025",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Environmental surveillance is Pakistan's early warning system for poliovirus detection. By testing sewage and wastewater samples from designated collection sites across the country, the programme can detect the presence of poliovirus in communities even before any child shows symptoms of paralysis — since for every paralytic case, approximately 200 children carry and transmit the virus silently.</p>

<h2>Sampling Network &amp; Laboratory Analysis</h2>
<p>Pakistan operates one of the world's most extensive polio environmental surveillance networks, with 115 active sampling sites distributed across 53 cities in all four provinces, Gilgit-Baltistan, Azad Jammu &amp; Kashmir, and Islamabad Capital Territory. Samples are collected on a regular schedule and transported under controlled conditions to WHO-accredited laboratories at the National Institute of Health in Islamabad.</p>
<p>Laboratory analysis uses advanced molecular techniques including viral isolation and genomic sequencing to identify the specific lineage of any detected poliovirus. This genetic information is critical for understanding transmission pathways — it reveals whether a virus detected in one city is genetically linked to cases or detections in other areas, helping epidemiologists map the virus's geographic spread.</p>

<h2>Results Interpretation &amp; Programme Response</h2>
<p>When environmental samples test positive for wild poliovirus (WPV1) or circulating vaccine-derived poliovirus (cVDPV), the affected district immediately escalates its response. Additional vaccination campaigns are scheduled, campaign quality is intensified, and community mobilization efforts are strengthened to reach previously missed children.</p>
<p>Cities with persistent positive environmental samples receive special attention under the programme's "laser focus" strategy, which concentrates resources on the specific union councils and neighborhoods most likely to harbor the virus. This data-driven approach has been instrumental in reducing virus circulation over time.</p>
<p>The environmental surveillance results are shared with provincial and district emergency operations centres, WHO, UNICEF, and other Global Polio Eradication Initiative partners to inform coordinated planning and resource allocation decisions.</p>`

  return (
    <PolioInfoPage
      title="Environmental Surveillance Results – July 2025"
      path="/media-room/media-releases/2651-environmental-surveillance-results-july-2025"
      contentHtml={content}
      metrics={[
        { label: "Sampling Sites", value: "115 Active" },
        { label: "Cities Covered", value: "53" },
        { label: "Analysis", value: "WHO-Accredited" },
        { label: "Period", value: "2025" }
      ]}
    />
  )
}
