import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Pakistan Reports 69th WPV1 Case of 2024",
  description: "The Regional Reference Laboratory for Polio Eradication at the National Institute of Health confirmed the detection of the 69th wild poliovirus type 1 (WPV...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2588-pakistan-reports-69th-wpv1-case-of-2024",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Regional Reference Laboratory for Polio Eradication at the National Institute of Health confirmed the detection of the 69th wild poliovirus type 1 (WPV1) case of 2024. The laboratory confirmation followed the standard WHO-accredited testing protocol, with stool samples collected within the mandatory 14-day window from onset of acute flaccid paralysis (AFP).</p>

<h2>Case Details &amp; Epidemiological Context</h2>
<p>The affected child, under five years of age, was identified through Pakistan's acute flaccid paralysis surveillance network — one of the most extensive disease detection systems in the world, covering over 750 sentinel surveillance sites nationwide. Genetic sequencing of the isolated virus provides critical information about the transmission chain, helping epidemiologists trace the virus's geographic movement across districts and provinces.</p>
<p>The affected district has been identified as an area of ongoing poliovirus circulation, where a combination of factors — including population mobility, variable campaign quality, and pockets of vaccine hesitancy — contribute to sustained transmission. The district's emergency operations centre immediately activated its outbreak response protocol following case confirmation.</p>

<h2>Programme Response &amp; Vaccination Operations</h2>
<p>Following confirmation, the National Emergency Operations Centre (NEOC) coordinated an immediate outbreak response vaccination campaign targeting all children under five within a defined radius of the case location. Response campaigns typically aim to vaccinate every eligible child within 72 hours of case confirmation, deploying hundreds of additional vaccination teams to the affected area.</p>
<p>Environmental surveillance data from sewage sampling sites in the region provides additional context for this case. Regular detection of poliovirus in environmental samples indicates community-level virus circulation even in the absence of paralytic cases, as the vast majority of poliovirus infections are asymptomatic but still contagious.</p>
<p>Parents and caregivers are reminded that there is no cure for polio — only prevention through vaccination. The oral polio vaccine (OPV) is safe, effective, and provided free of charge during all national and sub-national campaigns. Families who believe their children were missed during any campaign should call the Sehat Tahaffuz Helpline at 1166 to request a vaccination team visit.</p>`

  return (
    <PolioInfoPage
      title="Pakistan Reports 69th WPV1 Case of 2024"
      path="/media-room/media-releases/2588-pakistan-reports-69th-wpv1-case-of-2024"
      contentHtml={content}
      metrics={[
        { label: "Case Number", value: "#69" },
        { label: "Year", value: "2024" },
        { label: "Virus Type", value: "WPV1" },
        { label: "Response", value: "Outbreak Protocol" }
      ]}
    />
  )
}
