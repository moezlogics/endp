import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Government Will Make Pakistan a Polio-Free Country: Saira Tarar",
  description: "Government Will Make Pakistan a Polio-Free Country: Saira Tarar — this announcement demonstrates the high-level political commitment that is essential for...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/1342-government-will-make-pakistan-a-polio-free-country-saira-tarar",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Government Will Make Pakistan a Polio-Free Country: Saira Tarar — this announcement demonstrates the high-level political commitment that is essential for successful polio eradication. Government leadership provides the authority, resources, and institutional framework necessary to conduct nationwide vaccination campaigns and sustain the complex operational infrastructure required to reach every child.</p>

<h2>Policy Framework &amp; Institutional Support</h2>
<p>Pakistan's polio eradication programme operates as a national emergency, reflecting the government's recognition that poliovirus elimination is both a public health imperative and a matter of national pride. The programme is overseen by the Prime Minister's Focal Person for Polio Eradication and coordinated through the National Emergency Operations Centre (NEOC), which brings together federal and provincial resources under a unified command structure.</p>
<p>Government support extends beyond funding and policy directives. It includes deployment of security forces to protect vaccination teams in high-risk areas, use of government infrastructure for vaccine storage and cold chain management, mobilization of civil administration for campaign logistics, and engagement of elected representatives as vaccination advocates in their constituencies.</p>

<h2>Accountability &amp; Progress Monitoring</h2>
<p>Performance accountability mechanisms ensure that campaign quality is maintained across all districts. Regular review meetings at provincial and federal levels assess campaign results, identify underperforming areas, and implement corrective measures. This accountability framework has been instrumental in driving improvements in vaccination coverage over time.</p>
<p>The government's commitment is reinforced by Pakistan's international obligations as a member of the World Health Assembly, which has designated polio eradication as a global public health emergency. Pakistan works closely with neighboring Afghanistan — the only other country where wild poliovirus still circulates — to coordinate cross-border vaccination strategies.</p>
<p>Sustained political commitment at every level — from union councils to the Prime Minister's office — is recognized as one of the most critical success factors for achieving and maintaining a polio-free Pakistan.</p>`

  return (
    <PolioInfoPage
      title="Government Will Make Pakistan a Polio-Free Country: Saira Tarar"
      path="/media-room/media-releases/1342-government-will-make-pakistan-a-polio-free-country-saira-tarar"
      contentHtml={content}
      metrics={[
        { label: "Authority", value: "Federal Government" },
        { label: "Coordination", value: "NEOC" },
        { label: "Priority", value: "National Emergency" },
        { label: "Year", value: "Ongoing" }
      ]}
    />
  )
}
