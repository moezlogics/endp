import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "In Pakistan, Religious Leaders Help Change Misconceptions About the Polio Vaccine",
  description: "This article highlights the significant role of religious leaders in addressing misconceptions about the polio vaccine in Pakistan. It underscores how thei...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/field-stories/in-pakistan-religious-leaders-help-change-misconceptions-about-the-polio-vaccine",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This article highlights the significant role of religious leaders in addressing misconceptions about the polio vaccine in Pakistan. It underscores how their involvement is crucial for building trust within communities and increasing vaccination coverage, ultimately contributing to polio eradication efforts.</p>

<h2>Key Themes</h2>
<p>Role of Religious Leaders: Religious figures are actively engaged in dispelling myths and providing accurate information about the polio vaccine.</p>
<p>Community Trust: Their endorsement helps overcome hesitancy and encourages parents to vaccinate their children.</p>
<p>Public Health Impact: This community-based approach is vital for achieving high immunization rates and protecting children from paralysis.</p>
<p>Cultural Sensitivity: The article emphasizes the importance of culturally and religiously sensitive communication strategies in public health initiatives.</p>
<p>Understanding this role is essential for appreciating the multifaceted approach required for polio eradication in Pakistan and the value of community-based interventions.</p>`

  return (
    <PolioInfoPage
      title="In Pakistan, Religious Leaders Help Change Misconceptions About the Polio Vaccine"
      path="/media-room/field-stories/in-pakistan-religious-leaders-help-change-misconceptions-about-the-polio-vaccine"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Field Story" },
        { label: "Focus", value: "Community Impact" },
        { label: "Workers", value: "350,000+ Deployed" },
        { label: "Goal", value: "Zero Polio Cases" }
      ]}
    />
  )
}
