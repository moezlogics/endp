import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Pakistan Polio Briefer (Incomplete URL)",
  description: "This briefer provides an official update on Pakistan's polio eradication status for the reporting period. Published by the National Emergency Operations Ce...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/polio-briefer/Pakistan",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This briefer provides an official update on Pakistan's polio eradication status for the reporting period. Published by the National Emergency Operations Centre (NEOC), the document summarizes the latest case counts, environmental surveillance findings, campaign results, and operational developments — giving stakeholders a comprehensive snapshot of programme performance and epidemiological trends.</p>

<h2>Epidemiological Summary &amp; Surveillance Data</h2>
<p>The update covers both wild poliovirus type 1 (WPV1) and circulating vaccine-derived poliovirus (cVDPV) detections during the reporting period. Case data is presented by province and district, allowing readers to see exactly where virus activity was concentrated. Environmental surveillance results from Pakistan's network of 115 sewage sampling sites across 53 cities provide complementary evidence of virus circulation patterns.</p>
<p>Genetic sequencing of isolated viruses — conducted at WHO-accredited reference laboratories — reveals transmission chains and geographic linkages between different detection sites. This molecular epidemiology is essential for understanding how the virus moves through populations and where intervention resources should be concentrated.</p>

<h2>Campaign Performance &amp; Programme Activities</h2>
<p>The briefer reports on vaccination campaigns conducted during the period, including coverage estimates, quality indicators, and lessons learned. Post-campaign monitoring data reveals the proportion of children successfully reached, the reasons for any coverage gaps, and the specific districts or union councils requiring follow-up activities.</p>
<p>Programme innovations and operational improvements introduced during the period are documented, along with partnership developments and resource mobilization activities. This information is valuable for donors, implementing partners, and government officials who need to track programme progress and make evidence-based decisions about resource allocation.</p>
<p>The document concludes with a forward-looking assessment of priorities and planned activities for the coming period, ensuring continuity of strategic focus across reporting cycles.</p>`

  return (
    <PolioInfoPage
      title="Pakistan Polio Briefer (Incomplete URL)"
      path="/images/polio-briefer/pakistan"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Briefer" },
        { label: "Period", value: "the reporting period" },
        { label: "Data Source", value: "NEOC / WHO" },
        { label: "Format", value: "PDF Bulletin" }
      ]}
    />
  )
}
