import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Baseline Survey Report – Polio Immunization Coverage & Community Attitudes in South Khyber Pakhtunkhwa | End Polio Pakistan",
  description: "Baseline Survey Report – Polio Immunization Coverage & Community Attitudes in South Khyber Pakhtunkhwa | End Polio Pakistan — this official document from t...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/reports/Report-on-Baseline-Survey-in-South%20KP.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Baseline Survey Report – Polio Immunization Coverage & Community Attitudes in South Khyber Pakhtunkhwa | End Polio Pakistan — this official document from the Pakistan Polio Eradication Programme provides strategic analysis, operational data, and evidence-based recommendations for strengthening the national response to poliovirus. As a reference document for programme managers, policymakers, and international partners, it reflects the current state of knowledge and the programme's priorities for the period covered.</p>

<h2>Core Findings &amp; Analysis</h2>
<p>The report presents a comprehensive assessment of Pakistan's polio situation based on multiple data sources: acute flaccid paralysis (AFP) surveillance data, environmental surveillance results from the national network of sewage sampling sites, campaign coverage assessments, and routine immunization records. Together, these data streams provide a multidimensional view of both virus circulation patterns and programme performance.</p>
<p>Key epidemiological findings include the geographic distribution of confirmed cases and environmental detections, genetic sequencing results that reveal transmission linkages between different outbreak areas, and trend analysis showing changes in virus circulation patterns over time. The report identifies specific districts and union councils where programme performance needs strengthening.</p>

<h2>Action Plan &amp; Strategic Guidelines</h2>
<p>Strategic recommendations address the programme's core operational pillars: improving campaign quality to reach every eligible child, strengthening routine immunization to build sustainable population immunity, enhancing surveillance sensitivity to detect virus circulation early, and intensifying community engagement to reduce vaccine refusal and hesitancy.</p>
<p>The report also documents the programme's financial management, partnership coordination, and capacity building activities. These institutional dimensions are critical for sustaining the large-scale operational infrastructure required for polio eradication over the long term.</p>
<p>For researchers, health professionals, and students of public health, this document serves as a primary source for understanding how Pakistan — one of the last two countries where wild poliovirus circulates — is managing one of the most complex disease eradication efforts in global health history.</p>`

  return (
    <PolioInfoPage
      title="Baseline Survey Report – Polio Immunization Coverage & Community Attitudes in South Khyber Pakhtunkhwa | End Polio Pakistan"
      path="/images/reports/report-on-baseline-survey-in-south-kp-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Official Report" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Period", value: "Multi-Year" },
        { label: "Status", value: "Published" }
      ]}
    />
  )
}
