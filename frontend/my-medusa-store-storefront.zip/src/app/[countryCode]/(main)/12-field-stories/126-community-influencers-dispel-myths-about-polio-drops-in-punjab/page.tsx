import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Community Influencers Dispel Myths About Polio Drops in Punjab",
  description: "Community Influencers Dispel Myths About Polio Drops in Punjab — this field story from Pakistan's polio eradication frontlines captures the human dimension...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/12-field-stories/126-community-influencers-dispel-myths-about-polio-drops-in-punjab",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Community Influencers Dispel Myths About Polio Drops in Punjab — this field story from Pakistan's polio eradication frontlines captures the human dimension of a programme that deploys over 350,000 workers during each national campaign. Behind every statistic in the programme's data dashboards are real people — vaccinators, supervisors, social mobilizers, and the communities they serve — whose daily efforts determine whether Pakistan will achieve its goal of a polio-free future.</p>

<h2>Frontline Challenges &amp; Community Action</h2>
<p>Pakistan's frontline polio workers operate in some of the world's most demanding environments. They carry insulated vaccine carriers through extreme heat in Sindh's summer months, navigate mountainous terrain in Khyber Pakhtunkhwa's northern districts, cross rivers and flood-affected areas during monsoon season, and work extended hours to reach every child in urban slums where population density makes systematic coverage exceptionally difficult.</p>
<p>The social dimension of their work is equally challenging. Many frontline workers — the majority of whom are women — must engage with families who have concerns about vaccination, address misconceptions, and build the trust that is essential for acceptance. This requires communication skills, patience, cultural sensitivity, and genuine commitment to child health that goes far beyond a simple job description.</p>

<h2>Future Goals &amp; Key Takeaways</h2>
<p>Community engagement strategies have evolved significantly over the years. Today's programme uses data from previous campaigns to identify specific households where children were missed or refused, enabling targeted follow-up visits. Social mobilizers engage with community leaders, religious scholars, and influential figures in advance of each campaign to build community ownership of vaccination efforts.</p>
<p>The stories of individual workers and communities illustrate both the progress made and the challenges remaining. Each successfully vaccinated child represents a small victory in the larger battle against poliovirus. Each resistant household overcome through patient dialogue represents a community strengthened against misinformation.</p>
<p>These field stories serve as a reminder that polio eradication is ultimately a human endeavor — achieved not through technology or policy alone, but through the dedication of hundreds of thousands of individuals working together toward a common goal: ensuring that no Pakistani child ever suffers from the devastating, irreversible effects of poliovirus paralysis.</p>`

  return (
    <PolioInfoPage
      title="Community Influencers Dispel Myths About Polio Drops in Punjab"
      path="/12-field-stories/126-community-influencers-dispel-myths-about-polio-drops-in-punjab"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Field Story" },
        { label: "Focus", value: "Community Impact" },
        { label: "Workers", value: "350,000+ Deployed" },
        { label: "Goal", value: "Zero Polio Cases" }
      ]}
    />
  )
}
