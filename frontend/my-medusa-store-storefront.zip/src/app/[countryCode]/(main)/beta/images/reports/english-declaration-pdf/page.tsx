import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "English Declaration for Polio Eradication",
  description: "The Polio Eradication Declaration is a landmark document that outlines the global commitment and strategic roadmap for achieving the worldwide eradication...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/beta/images/reports/English-Declaration.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Polio Eradication Declaration is a landmark document that outlines the global commitment and strategic roadmap for achieving the worldwide eradication of poliovirus. Originating from the Global Polio Eradication Initiative (GPEI), this declaration serves as the foundational agreement among nations, health organizations, and partners to eliminate polio permanently.</p>

<h2>Key Highlights of the Declaration</h2>
<p>Shared Responsibility: It emphasizes that polio eradication is a global responsibility requiring coordinated action from all countries, especially those where the virus still circulates.</p>
<p>Strategic Pillars: The declaration outlines core strategies, including mass vaccination campaigns, surveillance systems to detect the virus quickly, laboratory confirmation, and community engagement to build trust and ensure coverage.</p>
<p>The Endgame Strategy: It supports the GPEI's Endgame Strategy, which focuses on stopping transmission, strengthening routine immunization, and ensuring that future generations remain polio-free throughIPV (Inactivated Poliovirus Vaccine) introduction and robust public health systems.</p>
<p>Resource Mobilization: It calls for sustained political commitment and financial investment to support the vaccination efforts, research, and operational costs associated with eradication.</p>
<p>Collaboration: The declaration underscores the importance of working with local communities, religious leaders, and healthcare workers to overcome cultural barriers and ensure that every child is vaccinated.</p>`

  return (
    <PolioInfoPage
      title="English Declaration for Polio Eradication"
      path="/beta/images/reports/english-declaration-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Official Report" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Period", value: "Multi-Year" },
        { label: "Status", value: "Published" }
      ]}
    />
  )
}
