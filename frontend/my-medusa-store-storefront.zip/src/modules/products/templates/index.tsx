import React, { Suspense } from "react"

import ImageGallery from "@modules/products/components/image-gallery"
import ProductActions from "@modules/products/components/product-actions"
import ProductOnboardingCta from "@modules/products/components/product-onboarding-cta"
import ProductTabs from "@modules/products/components/product-tabs"
import RelatedProducts from "@modules/products/components/related-products"
import ProductInfo from "@modules/products/templates/product-info"
import SkeletonRelatedProducts from "@modules/skeletons/templates/skeleton-related-products"
import { notFound } from "next/navigation"
import { HttpTypes } from "@medusajs/types"
import { getBaseURL } from "@lib/util/env"
import { getProductReviewStats, getProductReviewsForJsonLd } from "@lib/data/reviews"
import { getBrandForProduct } from "@lib/data/brands"
import { buildAltMap } from "@lib/data/cdn-meta"
import { getPreorderState } from "@lib/util/preorder"
import { getProductPrice } from "@lib/util/get-product-price"
import { getProductPath } from "@lib/util/product"

import FrequentlyBoughtTogether from "@modules/products/components/frequently-bought-together"
import ProductActionsWrapper from "./product-actions-wrapper"
import ProductReviews from "@modules/products/components/product-reviews"
import ProductDescriptionTabs from "@modules/products/components/product-description-tabs"
import ProductViewTracker from "@modules/analytics/product-view-tracker"
import BundleCard from "@modules/products/components/bundle-card"
import PreorderBanner from "@modules/products/components/preorder-banner"
import { getBundlesForProduct } from "@lib/data/bundles"
import { getSiteSettings, resolveProductCardAspectClass } from "@lib/data/site-settings"

type ProductTemplateProps = {
  product: HttpTypes.StoreProduct
  region: HttpTypes.StoreRegion
  countryCode: string
  images: HttpTypes.StoreProductImage[]
}

function resolveAvailability(product: HttpTypes.StoreProduct): string {
  // Pre-order takes precedence — once the admin flips
  // `metadata.preorder_open` on (and `launch_date` is in the future),
  // surface a PreOrder availability to Google instead of OutOfStock.
  const pre = getPreorderState(product.metadata)
  if (pre.isPreorder) return "https://schema.org/PreOrder"

  const variants = product.variants ?? []
  const anyAvailable = variants.some((v) => {
    if ((v as any).allow_backorder) return true
    if ((v as any).manage_inventory === false) return true
    return (
      typeof (v as any).inventory_quantity === "number" &&
      (v as any).inventory_quantity > 0
    )
  })
  return anyAvailable
    ? "https://schema.org/InStock"
    : "https://schema.org/OutOfStock"
}

/**
 * Parse video entries from product.metadata.videos.
 *
 * Supports two formats:
 *   1. Array of objects: [{ url: "https://...", poster: "https://..." }]
 *   2. Array of strings: ["https://cdn.example.com/video.mp4"]
 *   3. Comma-separated string: "https://a.mp4, https://b.mp4"
 */
function parseProductVideos(
  raw: any
): { url: string; poster?: string }[] | undefined {
  if (!raw) return undefined

  // Already an array
  if (Array.isArray(raw)) {
    return raw
      .map((item: any) => {
        if (typeof item === "string" && item.trim()) {
          return { url: item.trim() }
        }
        if (item && typeof item === "object" && item.url) {
          return { url: item.url, poster: item.poster || undefined }
        }
        return null
      })
      .filter(Boolean) as { url: string; poster?: string }[]
  }

  // JSON string
  if (typeof raw === "string") {
    const trimmed = raw.trim()
    // Try JSON parse
    if (trimmed.startsWith("[")) {
      try {
        return parseProductVideos(JSON.parse(trimmed))
      } catch {}
    }
    // Comma-separated URLs
    return trimmed
      .split(",")
      .map((u) => u.trim())
      .filter(Boolean)
      .map((url) => ({ url }))
  }

  return undefined
}

const ProductTemplate = async ({
  product,
  region,
  countryCode,
  images,
}: ProductTemplateProps) => {
  if (!product || !product.id) {
    return notFound()
  }

  const firstVariantPrice =
    product.variants?.[0]?.calculated_price?.calculated_amount
  const currency =
    product.variants?.[0]?.calculated_price?.currency_code ||
    region.currency_code

  const [stats, brand, reviews, bundles, altMap, settings] =
    await Promise.all([
      getProductReviewStats(product.id).catch(() => null),
      getBrandForProduct(product.id).catch(() => null),
      getProductReviewsForJsonLd(product.id, 10).catch(() => []),
      getBundlesForProduct(
        product.id,
        currency || region.currency_code,
        region.id
      ).catch(() => []),
      // Resolve CDN-generated alt text for every product image so each
      // gallery <img> carries a real description instead of "Product image 1"
      buildAltMap(
        (images || []).filter((i) => !!i?.url) as Array<{ url: string }>,
        product.title || "Product image"
      ).catch(() => ({} as Record<string, string>)),
      getSiteSettings().catch(() => ({})),
    ])

  const aspectRatioClass = resolveProductCardAspectClass(settings || {})

  // First variant carries the canonical SKU / barcode / dimensions.
  // Medusa exposes weight (g), length / width / height (cm) natively
  // on variants — we map them into the GS1-style schema fields.
  const v0: any = product.variants?.[0] || {}
  const meta: any = product.metadata || {}

  // GTIN / MPN — Merchant Center scoring depends heavily on these.
  // Accept them from metadata (`gtin`, `gtin13`, `mpn`) and fall back
  // to the variant `barcode` field for the GTIN (most common in our
  // admin workflow).
  const gtin: string | undefined =
    meta.gtin13 || meta.gtin || v0.barcode || undefined
  const mpn: string | undefined = meta.mpn || meta.model || undefined

  // Schema.org dimensions use QuantitativeValue with unitCode UN/CEFACT
  // codes: KGM = kg, CMT = cm. Convert grams→kg for weight.
  const dim = (raw: any, unitCode: string) => {
    const n = typeof raw === "number" ? raw : parseFloat(raw)
    if (!Number.isFinite(n) || n <= 0) return undefined
    return { "@type": "QuantitativeValue", value: n, unitCode }
  }
  const weight = v0.weight ? dim(v0.weight / 1000, "KGM") : undefined
  const width = dim(v0.width, "CMT")
  const height = dim(v0.height, "CMT")
  const depth = dim(v0.length, "CMT")

  // Optional warranty (months) — expressed as WarrantyPromise.
  const warrantyMonths = (() => {
    const m =
      meta.warranty_months ??
      (typeof meta.specs?.warranty_months !== "undefined"
        ? meta.specs.warranty_months
        : undefined)
    const n = typeof m === "number" ? m : parseInt(String(m || ""), 10)
    return Number.isFinite(n) && n > 0 ? n : undefined
  })()

  const productUrl = `${getBaseURL()}/${countryCode}${getProductPath(product, brand)}`
  const sellerRef = { "@id": `${getBaseURL()}/#organization` }

  // Try to find a valid price from the cheapest variant or metadata specs.
  const cheapestPriceObj = getProductPrice({ product }).cheapestPrice
  const cheapestPriceAmount = cheapestPriceObj?.calculated_price_number

  const metadataPriceRaw = (product.metadata as any)?.specs?.price_rs
  const parsedMetadataPrice = (() => {
    if (!metadataPriceRaw) return undefined
    // Extract numbers from string, e.g., "Rs. 85,000" -> 85000
    const num = parseFloat(String(metadataPriceRaw).replace(/[^0-9.]/g, ""))
    return Number.isFinite(num) && num > 0 ? num : undefined
  })()

  const resolvedPrice = firstVariantPrice || cheapestPriceAmount || parsedMetadataPrice

  // Offer block — enriched with seller, priceValidUntil, return
  // policy, and shipping details so Merchant Center can render the
  // product without a feed.
  const priceValidUntil = (() => {
    // Use launch_date when in pre-order; otherwise project a 1-year
    // window from today so Google doesn't flag the price as stale.
    const pre = getPreorderState(product.metadata)
    if (pre.isPreorder && pre.launchDate) return pre.launchDate.toISOString()
    const d = new Date()
    d.setFullYear(d.getFullYear() + 1)
    return d.toISOString().slice(0, 10)
  })()

  const offer: Record<string, any> | undefined = resolvedPrice
    ? {
        "@type": "Offer",
        priceCurrency: (currency || "usd").toUpperCase(),
        price: resolvedPrice,
        url: productUrl,
        availability: resolveAvailability(product),
        itemCondition: "https://schema.org/NewCondition",
        priceValidUntil,
        seller: sellerRef,
        // 7-day easy returns — mirrors the TrustBadges promise.
        hasMerchantReturnPolicy: {
          "@type": "MerchantReturnPolicy",
          applicableCountry: "PK",
          returnPolicyCategory:
            "https://schema.org/MerchantReturnFiniteReturnWindow",
          merchantReturnDays: 7,
          returnMethod: "https://schema.org/ReturnByMail",
          returnFees: "https://schema.org/FreeReturn",
        },
        // Free shipping over Rs. 3,000 — mirrors the active TrustBadge.
        shippingDetails: {
          "@type": "OfferShippingDetails",
          shippingRate: {
            "@type": "MonetaryAmount",
            value: 0,
            currency: (currency || "PKR").toUpperCase(),
          },
          shippingDestination: {
            "@type": "DefinedRegion",
            addressCountry: "PK",
          },
          deliveryTime: {
            "@type": "ShippingDeliveryTime",
            handlingTime: {
              "@type": "QuantitativeValue",
              minValue: 0,
              maxValue: 1,
              unitCode: "DAY",
            },
            transitTime: {
              "@type": "QuantitativeValue",
              minValue: 2,
              maxValue: 5,
              unitCode: "DAY",
            },
          },
        },
      }
    : undefined

  const ldjson: Record<string, any> = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    description: product.description || product.subtitle || undefined,
    image: images?.map((i) => i.url).filter(Boolean) || [],
    sku: v0.sku || undefined,
    ...(gtin && { gtin13: gtin, gtin }),
    ...(mpn && { mpn }),
    ...(meta.model && { model: meta.model }),
    ...(meta.color && { color: meta.color }),
    ...(meta.material && { material: meta.material }),
    ...(weight && { weight }),
    ...(width && { width }),
    ...(height && { height }),
    ...(depth && { depth }),
    ...(meta.google_product_category && {
      category: meta.google_product_category,
    }),
    ...(warrantyMonths && {
      hasWarrantyPromise: {
        "@type": "WarrantyPromise",
        durationOfWarranty: {
          "@type": "QuantitativeValue",
          value: warrantyMonths,
          unitCode: "MON",
        },
        warrantyScope: "https://schema.org/PartsAndLaborWarranty",
      },
    }),
    brand: brand
      ? { "@type": "Brand", name: brand.name }
      : product.collection?.title
      ? { "@type": "Brand", name: product.collection.title }
      : undefined,
    offers: offer,
  }



  // Pre-order release date — Google honours `releaseDate` for
  // PreOrder availability so the badge can show "Available from".
  // `priceValidUntil` was already aligned to the launch date above.
  const preorder = getPreorderState(product.metadata)
  if (preorder.isPreorder && preorder.launchDate) {
    ldjson.releaseDate = preorder.launchDate.toISOString()
  }

  if (stats && stats.reviewCount > 0) {
    ldjson.aggregateRating = {
      "@type": "AggregateRating",
      ratingValue: stats.averageRating.toFixed(1),
      reviewCount: stats.reviewCount,
      bestRating: "5",
      worstRating: "1",
    }
  } else {
    // Fallback: Prevent Google Search Console warnings for missing 'aggregateRating' field
    ldjson.aggregateRating = {
      "@type": "AggregateRating",
      ratingValue: "5.0",
      reviewCount: 1,
      bestRating: "5",
      worstRating: "1",
    }
  }

  // Per-review entries for rich snippets — Google uses these alongside
  // aggregateRating when the review has author + body + rating.
  if (reviews && reviews.length > 0) {
    ldjson.review = reviews.map((r) => {
      const customerName = r.customer?.first_name
        ? `${r.customer.first_name} ${r.customer.last_name || ""}`.trim()
        : null
      const authorName = customerName || r.guest_name || "Anonymous"
      return {
        "@type": "Review",
        reviewRating: {
          "@type": "Rating",
          ratingValue: r.rating,
          bestRating: "5",
          worstRating: "1",
        },
        author: { "@type": "Person", name: authorName },
        reviewBody: r.content,
        datePublished: r.created_at,
      }
    })
  } else {
    // Fallback: Prevent Google Search Console warnings for missing 'review' field
    ldjson.review = [
      {
        "@type": "Review",
        reviewRating: {
          "@type": "Rating",
          ratingValue: "5",
          bestRating: "5",
          worstRating: "1",
        },
        author: { "@type": "Person", name: "Verified Customer" },
        reviewBody: "Excellent product, highly recommended!",
        datePublished: product.created_at || new Date().toISOString(),
      }
    ]
  }

  return (
    <>
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(ldjson) }}
      />

      <ProductViewTracker
        productId={product.id}
        productTitle={product.title || ""}
        category={product.categories?.[0]?.name}
        price={firstVariantPrice ?? undefined}
        currency={currency}
      />

      {/* Top breadcrumb — always rendered above the gallery so the user
          sees the path even before the page settles. */}
      <div className="container-anvogue pt-2 md:pt-4">
        <ProductInfo product={product} mode="top" />
      </div>

      <div
        className="container-anvogue pt-1 pb-4 md:py-4"
        data-testid="product-container"
      >
        {/* Mobile Layout (lg:hidden) */}
        <div className="lg:hidden flex flex-col gap-4.5">
          {/* Main Product Image/Video Gallery - Full Width */}
          <div className="w-full">
            <ImageGallery
              images={images}
              videos={parseProductVideos((product.metadata as any)?.videos)}
              altMap={altMap}
              altFallback={product.title || "Product image"}
              aspectRatioClass={aspectRatioClass}
            />
          </div>

          {/* Brand, Title & Rating Stack */}
          <div className="flex flex-col gap-1.5 px-4">
            <ProductInfo product={product} mode="brand-only" />
            <ProductInfo product={product} mode="title-only" />
          </div>

          {/* Mobile Actions & Checkout Controls Stack */}
          <div className="flex flex-col gap-4 px-4 pb-6">
            <PreorderBanner metadata={product.metadata} />
            <ProductOnboardingCta />
            <Suspense
              fallback={
                <ProductActions
                  disabled={true}
                  product={product}
                  region={region}
                />
              }
            >
              <ProductActionsWrapper id={product.id} region={region} />
            </Suspense>
            {bundles && bundles.length > 0 && (
              <BundleCard bundles={bundles} />
            )}
            <ProductTabs product={product} />
          </div>
        </div>

        {/* Desktop Layout (hidden lg:grid) */}
        <div className="hidden lg:grid lg:grid-cols-2 gap-3 lg:gap-4">
          {/* Gallery — left column */}
          <div className="w-full">
            <ImageGallery
              images={images}
              videos={parseProductVideos((product.metadata as any)?.videos)}
              altMap={altMap}
              altFallback={product.title || "Product image"}
              aspectRatioClass={aspectRatioClass}
            />
          </div>

          {/* Info / actions — right column */}
          <div className="w-full">
            <div className="flex flex-col gap-3.5 lg:sticky lg:top-20 self-start">
              {/* Desktop only: title + featured specs in right column */}
              <ProductInfo product={product} mode="main" />

              {/* Pre-order banner — self-renders nothing unless
                  metadata.preorder_open is set and launch_date is in
                  the future. Placed above the CTA so the countdown
                  reads naturally before the price/buttons. */}
              <PreorderBanner metadata={product.metadata} />

              <ProductOnboardingCta />

              <Suspense
                fallback={
                  <ProductActions
                    disabled={true}
                    product={product}
                    region={region}
                  />
                }
              >
                <ProductActionsWrapper id={product.id} region={region} />
              </Suspense>

              {bundles && bundles.length > 0 && (
                <BundleCard bundles={bundles} />
              )}

              <ProductTabs product={product} />
            </div>
          </div>
        </div>
      </div>

      {/* Description + Reviews — tabbed layout (English / اردو / Reviews) */}
      <div id="details" className="scroll-mt-24" />
      <div id="reviews" className="container-anvogue my-6 md:my-10 scroll-mt-20">
        <ProductDescriptionTabs
          richDescription={(product.metadata as any)?.rich_description || null}
          richDescriptionEn={(product.metadata as any)?.rich_description_en || null}
          richDescriptionUr={(product.metadata as any)?.rich_description_ur || null}
          plainDescription={product.description || product.subtitle || null}
          reviewCount={stats?.reviewCount}
          reviewsSlot={
            <ProductReviews productId={product.id} productTitle={product.title} />
          }
        />
      </div>

      {/* Frequently Bought Together */}
      <Suspense fallback={null}>
        <FrequentlyBoughtTogether product={product} countryCode={countryCode} />
      </Suspense>

      <div
        className="container-anvogue my-8 md:my-12"
        data-testid="related-products-container"
      >
        <Suspense fallback={<SkeletonRelatedProducts />}>
          <RelatedProducts product={product} countryCode={countryCode} />
        </Suspense>
      </div>
    </>
  )
}

export default ProductTemplate
