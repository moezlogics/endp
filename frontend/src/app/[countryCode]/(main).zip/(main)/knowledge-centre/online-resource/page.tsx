import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Eradication Online Resources Pakistan – Research Papers, Educational Tools & Technical References | End Polio Pakistan Knowledge Centre",
  description: "The Online Resources section of End Polio Pakistan's Knowledge Centre is a curated digital library providing access to research papers, technical guidance documents.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/knowledge-centre/online-resource",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Online Resources section of End Polio Pakistan's Knowledge Centre is a curated digital library providing access to research papers, technical guidance documents, educational materials, and external links relevant to polio eradication in Pakistan and globally. This section serves as a one-stop reference for health professionals, researchers, students, policymakers, and advocates working in the field of polio and immunization.</p>

<h2>Key Objectives & Focus</h2>
<p>Resources available through this section span multiple categories. Peer-reviewed research papers on poliovirus epidemiology, vaccine effectiveness, and community engagement strategies are compiled from leading journals. Technical guidance documents from WHO, UNICEF, and the Global Polio Eradication Initiative provide standards and protocols for programme implementation.</p>
<p>Educational materials including training manuals for vaccination teams, communication toolkits for social mobilizers, and instructional guides for surveillance officers are made freely available to support capacity building at all levels of the programme. These resources enable consistent, high-quality programme delivery across Pakistan's diverse operational environments.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Links to international data portals, environmental surveillance databases, and global polio case trackers allow users to situate Pakistan's situation within the broader global eradication effort. Understanding global context is essential for appreciating the stakes involved in Pakistan's remaining challenge.</p>
<p>All resources are regularly reviewed and updated to reflect the latest scientific evidence and programmatic learning. The Online Resources section embodies the programme's commitment to knowledge sharing and transparency, ensuring that the best available evidence informs decisions at every level of Pakistan's polio eradication effort.</p>
`

  return (
    <PolioInfoPage
      title="Online Resources for Polio Eradication – Research, Reports & Educational Materials | Knowledge Centre"
      path="/knowledge-centre/online-resource"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
