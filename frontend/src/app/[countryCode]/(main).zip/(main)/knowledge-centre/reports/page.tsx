import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Reports | Knowledge Centre | End Polio Pakistan",
  description: "The Knowledge Centre Reports page on End Polio Pakistan provides a centralized repository of official documents related to Pakistan's polio eradicatio...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/knowledge-centre/reports",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Knowledge Centre Reports page on End Polio Pakistan provides a centralized repository of official documents related to Pakistan's polio eradication effort. This section is an invaluable resource for researchers, health professionals, policymakers, journalists, and development workers seeking authoritative data and strategic documents.</p>

<h2>Core Findings & Analysis</h2>
<p>Available reports include National Emergency Action Plans (NEAPs) from multiple years, monthly Pakistan Polio Updates, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">environmental surveillance</a> summaries, <a href="/images/Stories/15th-IMB-Report-FINAL.pdf" class="text-blue-600 hover:underline">Independent Monitoring Board</a> assessments, and technical guidance documents. Together, these materials tell the comprehensive story of Pakistan's two-decade journey toward eradication.</p>
<p>Each <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> document outlines the operational strategy for a given year, detailing planned campaign rounds, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">surveillance</a> targets, community mobilization activities, and accountability measures. Monthly updates provide granular data on cases, environmental findings, and campaign performance.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>The reports section also includes specialized documents on topics such as the role of female health workers, cross-border coordination, the impact of COVID-19 on immunization activities, and the use of technology to improve campaign performance.</p>
<p>All documents are available for free download, reflecting the programme's commitment to transparency and knowledge sharing. The information supports evidence-based decision-making at every level of the programme hierarchy, from national coordinators to district health officers.</p>
<p>For anyone seeking to understand Pakistan's <a href="/polioin-pakistan/eradication-strategy" class="text-blue-600 hover:underline">polio eradication strategy</a> in depth, the Knowledge Centre Reports page is the essential starting point.</p>
`

  return (
    <PolioInfoPage
      title="Reports | Knowledge Centre | End Polio Pakistan"
      path="/knowledge-centre/reports"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
