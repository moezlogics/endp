import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "IPV Polio Vaccine Training Video Pakistan – Correct Administration Guide for Health Workers | End Polio Pakistan",
  description: "This training video is a critical resource for healthcare workers and vaccination staff responsible for administering the inactivated polio vaccine (IPV).",
  alternates: {
    canonical: "https://www.endpolio.com.pk/training-material-final-ipv-video",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This training video is a critical resource for healthcare workers and vaccination staff responsible for administering the inactivated polio vaccine (IPV) as part of Pakistan's routine immunization and polio eradication activities. IPV, which is given by injection rather than as oral drops, was introduced into Pakistan's programme as an important complement to the oral polio vaccine (OPV).</p>

<h2>Key Objectives & Focus</h2>
<p>Unlike OPV, which is administered orally and provides intestinal immunity, IPV stimulates a stronger blood-borne immune response and helps prevent the rare cases of vaccine-derived poliovirus that can occur in populations with low OPV coverage. The combination of both vaccines provides the most complete protection against all forms of poliovirus.</p>
<p>The training video demonstrates the correct technique for IPV administration: proper injection site identification (typically the upper outer thigh or upper arm depending on the child's age), correct needle angle, appropriate dosage, and post-injection care. It also covers cold chain management requirements for IPV, which has more stringent temperature sensitivity than OPV.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Common errors in IPV administration are identified and corrected in the video, including incorrect injection depth, improper site selection, and failures in aseptic technique. These corrections are important because incorrect administration can reduce vaccine effectiveness or cause adverse reactions.</p>
<p>The training video is used in pre-campaign training sessions for vaccination staff and is available on the End Polio Pakistan website for ongoing self-directed learning. High-quality training is essential for ensuring that every IPV dose administered contributes fully to building Pakistan's population immunity against poliovirus.</p>
`

  return (
    <PolioInfoPage
      title="IPV Training Video & Administration Guide"
      path="/training-material-final-ipv-video"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
