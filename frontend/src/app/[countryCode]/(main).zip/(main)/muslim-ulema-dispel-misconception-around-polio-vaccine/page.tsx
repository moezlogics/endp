import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Muslim Ulema Dispel Misconceptions Around Polio Vaccine",
  description: "This article highlights the significant role of Islamic scholars (Ulema) in combating misinformation and promoting polio vaccination across Pakistan.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/muslim-ulema-dispel-misconception-around-polio-vaccine",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This article highlights the significant role of Islamic scholars (Ulema) in combating misinformation and promoting polio vaccination across Pakistan. It addresses the critical need for religious leaders to actively support polio eradication efforts by dispelling myths and encouraging parents to vaccinate their children.</p>

<h2>Key Objectives & Focus</h2>
<p>The piece serves as a call to action for religious leaders to continue their support for polio eradication, emphasizing that vaccination aligns with Islamic principles of preserving life, protecting health, and looking after the welfare of the family and community.</p>
`

  return (
    <PolioInfoPage
      title="Muslim Ulema Dispel Misconceptions Around Polio Vaccine"
      path="/muslim-ulema-dispel-misconception-around-polio-vaccine"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
