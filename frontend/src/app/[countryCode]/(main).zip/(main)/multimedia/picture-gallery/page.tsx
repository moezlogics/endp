import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Eradication in Pakistan Photo Gallery – Vaccination Campaigns, Field Workers & Community Outreach | End Polio Pakistan",
  description: "The Picture Gallery section of End Polio Pakistan provides a powerful visual documentation of Pakistan's decades-long battle against poliovirus. Through hundreds of photographs captured across the country's most challenging environments.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/multimedia/picture-gallery",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Picture Gallery section of End Polio Pakistan provides a powerful visual documentation of Pakistan's decades-long battle against poliovirus. Through hundreds of photographs captured across the country's most challenging environments, this gallery brings to life the human stories behind the statistics and press releases.</p>

<h2>Key Objectives & Focus</h2>
<p>The images capture frontline vaccination workers carrying vaccine coolers through mountainous terrain in Khyber Pakhtunkhwa, female health workers administering polio drops in Balochistan's remote villages, transit vaccination teams working at border crossings and railway stations, and children receiving their protective doses in the homes, schools, and streets of Pakistan's cities.</p>
<p>High-level advocacy events are also documented — prime ministerial addresses, international delegation visits, World Polio Day ceremonies, and partnership announcements — showing the political and diplomatic dimensions of the eradication effort.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Perhaps the most impactful photographs are those showing paralyzed children and their families, whose stories serve as constant reminders of why this work matters. Every image of a vaccinated, healthy child playing freely is a counterpoint — proof of what vaccination makes possible.</p>
<p>The gallery is updated regularly with photographs from current campaigns and field activities. It serves as a transparency and accountability tool, showing donors and the public what their support funds in practice. For journalists, educators, and advocates, the picture gallery provides a rich visual resource for communicating the realities of Pakistan's polio eradication journey.</p>
`

  return (
    <PolioInfoPage
      title="Pakistan Polio Eradication Photo Gallery – Frontline Workers, Vaccination Campaigns & Field Operations"
      path="/multimedia/picture-gallery"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
