import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Eradication Pakistan Video Gallery – Vaccination Campaigns, Awareness Films & Field Documentaries | End Polio Pakistan",
  description: "The Video Gallery on End Polio Pakistan is a curated collection of films, documentaries, public service announcements, and field footage that tell the story of Pakistan's fight against poliovirus.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/multimedia/video-gallery",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Video Gallery on End Polio Pakistan is a curated collection of films, documentaries, public service announcements, and field footage that tell the story of Pakistan's fight against poliovirus in a dynamic, accessible format. Video content reaches audiences — particularly younger and less literate viewers — in ways that written content cannot.</p>

<h2>Key Objectives & Focus</h2>
<p>The gallery includes television awareness campaigns featuring celebrity ambassadors like Wasim Akram, public service announcements broadcast across Pakistan's major TV channels, and short documentary films profiling frontline workers and communities. Each piece is designed to inform, inspire, and motivate viewers to support vaccination.</p>
<p>Field footage from campaigns across all four provinces captures the on-the-ground reality of polio eradication: the logistical complexity of deploying hundreds of thousands of workers simultaneously, the community interactions that determine whether children receive their drops, and the moments of success when previously resistant households open their doors.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Training videos for vaccination teams and supervisors are also included, demonstrating correct vaccine administration techniques, household visit protocols, and cold chain management procedures. These videos serve as practical tools for improving campaign quality.</p>
<p>The video gallery also archives historical footage documenting Pakistan's eradication journey from the early campaign years to the present, providing a visual record of progress made and challenges overcome. For educators, journalists, and advocates, this library of audiovisual content is an invaluable resource for communicating the importance of polio vaccination.</p>
`

  return (
    <PolioInfoPage
      title="Pakistan Polio Eradication Video Gallery"
      path="/multimedia/video-gallery"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
