import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Frontline Polio Workers in Pakistan – Heroes Protecting Children from Poliovirus Every Day | End Polio Pakistan",
  description: "This field story pays tribute to Pakistan's frontline polio vaccination workers — the men and women who form the country's most essential line of defence against poliovirus.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/field-stories/frontline-workers-the-frontline-of-defence-against-polio",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This field story pays tribute to Pakistan's frontline polio vaccination workers — the men and women who form the country's most essential line of defence against poliovirus. With over 260,000 vaccinators deployed during each national campaign, these workers collectively represent the largest public health workforce ever assembled for a single disease programme.</p>

<h2>Frontline Challenges & Community Action</h2>
<p>Frontline workers operate in every corner of Pakistan, from the megacity neighborhoods of Karachi to the high-altitude villages of Gilgit-Baltistan, from the desert plains of Balochistan to the conflict zones of South Waziristan. Their common mission is simple but vital: reach every child under five with two drops of oral polio vaccine.</p>
<p>The story documents the daily realities these workers face. They carry heavy vaccine carriers in extreme heat, navigate flooded roads during monsoon season, face doors slammed in their faces by vaccine-hesitant families, and in some areas work under genuine security threats. Yet they return, day after day, campaign after campaign.</p>

<h2>Future Goals & Key Takeaways</h2>
<p>Female frontline workers deserve special recognition. In conservative communities, they gain access that male colleagues cannot, speaking mother-to-mother about the importance of protecting children. Their role has been credited with dramatically improving coverage in previously resistant households.</p>
<p>This field story is a call to Pakistani society to recognize, protect, and support these workers. They are not just health employees — they are the human shield standing between poliovirus and Pakistan's children, working tirelessly so that every child grows up strong and healthy.</p>
`

  return (
    <PolioInfoPage
      title="Frontline Workers: Pakistan's First Line of Defence Against Polio Eradication"
      path="/media-room/field-stories/frontline-workers-the-frontline-of-defence-against-polio"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Field Story" },
        { label: "Focus", value: "Community Health" },
        { label: "Staff Role", value: "Frontline Workers" },
        { label: "Scope", value: "District Level" }
      ]}
    />
  )
}
