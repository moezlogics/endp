import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Punjab Polio Campaign Mobile App – Digital Innovation to Improve Vaccination Coverage & Real-Time Tracking | End Polio Pakistan",
  description: "This field story documents a significant technological innovation in Pakistan's polio eradication effort: the piloting of a new mobile application in Punjab province.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/field-stories/punjab-pilots-new-mobile-app-to-eradicate-polio",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This field story documents a significant technological innovation in Pakistan's polio eradication effort: the piloting of a new mobile application in Punjab province designed to improve campaign tracking, coverage monitoring, and real-time data management during vaccination drives.</p>

<h2>Frontline Challenges & Community Action</h2>
<p>The mobile app enables vaccination teams to record households visited, children vaccinated, and cases of vaccine refusal directly on smartphones or tablets during field operations. This real-time data capture replaces traditional paper-based recording, which was prone to errors, delays, and data loss — problems that made it difficult for supervisors to identify coverage gaps quickly enough to address them during ongoing campaigns.</p>
<p>With the mobile app, supervisors and district managers can view live dashboards showing exactly which areas have been covered, where teams are currently working, and where children have been missed. This enables same-day corrections rather than end-of-day or post-campaign adjustments, significantly improving the completeness of each vaccination round.</p>

<h2>Future Goals & Key Takeaways</h2>
<p>The app also integrates with geographic information system (GIS) mapping, allowing programme managers to visualize coverage on district maps and identify geographic patterns in refusals or missed households. This spatial intelligence transforms how campaigns are managed.</p>
<p>Punjab's pilot results demonstrated measurable improvements in coverage completeness and data quality compared to previous campaigns. The success of the pilot informed the decision to scale the application to other provinces, representing one of the most impactful technological contributions to Pakistan's eradication effort in recent years.</p>
`

  return (
    <PolioInfoPage
      title="Punjab Pilots New Mobile App to Improve Polio Eradication Campaign Tracking and Coverage"
      path="/media-room/field-stories/punjab-pilots-new-mobile-app-to-eradicate-polio"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Field Story" },
        { label: "Focus", value: "Community Health" },
        { label: "Staff Role", value: "Frontline Workers" },
        { label: "Scope", value: "District Level" }
      ]}
    />
  )
}
