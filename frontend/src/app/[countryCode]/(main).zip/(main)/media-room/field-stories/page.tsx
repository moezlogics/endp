import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Eradication Field Stories Pakistan – Frontline Workers, Community Impact & Human Stories | End Polio Pakistan",
  description: "The Field Stories section of End Polio Pakistan's Media Room is one of the most compelling corners of the programme's communications — a collection of human stories from the frontlines.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/field-stories",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Field Stories section of End Polio Pakistan's Media Room is one of the most compelling corners of the programme's communications — a collection of human stories from the frontlines of Pakistan's battle against poliovirus. While press releases communicate data and policy, field stories communicate the lived experience of the people who make eradication possible.</p>

<h2>Frontline Challenges & Community Action</h2>
<p>Each story is carefully reported and written to bring a specific aspect of the programme to life. Stories profile individual vaccinators who have served for years in difficult conditions, communities that transformed from vaccine-resistant to vaccination champions, children whose futures were protected by timely immunization, and programme innovations that changed the way campaigns are conducted.</p>
<p>The geographical range of stories is vast: from urban slums in Karachi where team leaders navigate dense apartment blocks, to mountain villages in KP accessible only on foot, to nomadic communities in Balochistan that move with the seasons. Each environment presents unique challenges, and each story reveals unique solutions.</p>

<h2>Future Goals & Key Takeaways</h2>
<p>Field stories serve multiple programmatic purposes. Internally, they recognize and celebrate the work of frontline staff, building morale and motivation. Externally, they build public support for the programme by showing what the eradication effort looks like in practice. For donors and partners, they provide qualitative evidence of programme impact that complements the quantitative data in official reports.</p>
<p>This section is updated regularly and represents the most authentic, human face of Pakistan's extraordinary public health mission.</p>
`

  return (
    <PolioInfoPage
      title="End Polio Pakistan Field Stories – Inspiring Stories from the Frontlines of Polio Vaccination"
      path="/media-room/field-stories"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Field Story" },
        { label: "Focus", value: "Community Health" },
        { label: "Staff Role", value: "Frontline Workers" },
        { label: "Scope", value: "District Level" }
      ]}
    />
  )
}
