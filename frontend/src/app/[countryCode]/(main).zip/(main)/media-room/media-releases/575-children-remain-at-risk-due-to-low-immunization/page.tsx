import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Children Remain at Risk Due to Low Immunization",
  description: "This press release warns that a significant number of children across Pakistan remain vulnerable to poliovirus due to persistently low immunization coverage in specific districts.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/575-children-remain-at-risk-due-to-low-immunization",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release warns that a significant number of children across Pakistan remain vulnerable to poliovirus due to persistently low immunization coverage in specific districts. Despite progress made through national campaigns, pockets of unvaccinated children continue to fuel the risk of outbreaks.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>The statement highlights data showing that in certain high-risk union councils, a substantial proportion of children under the age of five have not received the recommended number of oral polio vaccine doses. Factors contributing to this gap include parental refusals, inaccessibility of remote areas, security threats to vaccination teams, and community mistrust.</p>
<p>The Pakistan Polio Eradication Programme urges parents, guardians, and community leaders to welcome vaccinators and ensure every child receives the drops. The oral polio vaccine is free, safe, and the only proven method of preventing polio, which can cause permanent paralysis within hours of infection.</p>

<h2>Public Health Impact & Operations</h2>
<p>Provincial governments and district health officers have been directed to intensify outreach efforts, particularly in areas with low coverage. Community mobilizers, religious scholars, and local influencers have been engaged to spread awareness.</p>
<p>The release concludes with a strong appeal: every missed child is a potential source of transmission. Collective action is essential to protect the most vulnerable and achieve a polio-free Pakistan.</p>
`

  return (
    <PolioInfoPage
      title="Children Remain at Risk Due to Low Immunization"
      path="/media-room/media-releases/575-children-remain-at-risk-due-to-low-immunization"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
