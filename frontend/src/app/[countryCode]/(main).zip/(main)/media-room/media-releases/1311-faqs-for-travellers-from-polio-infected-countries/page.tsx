import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Travel Requirements for Pakistan – FAQs on Vaccination Certificate, Approved Centers & WHO Guidelines | End Polio Pakistan",
  description: "This press release provides detailed frequently asked questions for international travelers departing Pakistan regarding polio vaccination requirements.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/1311-faqs-for-travellers-from-polio-infected-countries",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release provides detailed frequently asked questions for international travelers departing Pakistan regarding polio vaccination requirements. As Pakistan remains one of the few countries where wild poliovirus continues to circulate, the World Health Organization recommends that all residents and long-term visitors receive a polio vaccine dose before traveling internationally.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>The FAQs address the most common traveler queries comprehensively. Which countries require a polio vaccination certificate from Pakistani travelers? The answer changes periodically, but most countries that have eliminated polio maintain requirements for travelers from endemic countries. Travelers are advised to verify current requirements with their destination country's embassy.</p>
<p>What vaccine is needed? The FAQs explain that oral polio vaccine (OPV) or inactivated polio vaccine (IPV) are both accepted, and that the dose must be administered at a government-designated vaccination center by an authorized health officer who can issue and stamp the official International Certificate of Vaccination or Prophylaxis (ICVP).</p>

<h2>Public Health Impact & Operations</h2>
<p>How long is the certificate valid? The WHO currently recommends a certificate covering vaccination received between four weeks and twelve months before departure. Travelers making multiple international trips should maintain their vaccination within this window.</p>
<p>Where can travelers get vaccinated in Pakistan? The press release lists the types of approved centers available across major cities and provides guidance on finding the nearest authorized facility. The certificate process is straightforward and typically completed in a single visit.</p>
`

  return (
    <PolioInfoPage
      title="FAQs for International Travellers Departing Pakistan – Polio Vaccination Requirements & Certificate Information"
      path="/media-room/media-releases/1311-faqs-for-travellers-from-polio-infected-countries"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
