import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "40 Million Children to be Vaccinated Against Polio in Upcoming Nationwide Campaign",
  description: "This press release announces preparations for a major nationwide polio vaccination campaign targeting over 40 million children.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/611-40-million-children-to-be-vaccinated-against-polio-in-upcoming-nationwide-campaign",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release announces preparations for a major nationwide polio vaccination campaign targeting over 40 million children under the age of five across Pakistan. The campaign represents one of the largest single public health operations conducted in the country's history.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Teams of trained vaccinators were assembled, vaccine supplies coordinated, and a comprehensive microplanning process completed to ensure maximum coverage. Community mobilizers were deployed in advance to inform families about the campaign dates and the importance of vaccination.</p>
<p>The campaign targets children in all four provinces, Azad Kashmir, Gilgit-Baltistan, and Islamabad Capital Territory. Special focus was placed on high-risk districts identified through recent case data and environmental surveillance results, where extra teams and resources were allocated.</p>

<h2>Public Health Impact & Operations</h2>
<p>Health authorities emphasized that the oral polio vaccine is completely safe, free of charge, and requires only two drops administered directly into the child's mouth. No child is too young or too old to benefit, and parents were urged to ensure their children received the drops regardless of previous vaccination history.</p>
<p>Security arrangements were confirmed for areas where vaccination teams face threats, with thousands of law enforcement personnel deployed to accompany health workers.</p>
<p>The 40 million children target reflects the enormous scale of the task ahead and the government's commitment to protecting every child in Pakistan from the permanent paralysis that poliovirus can cause.</p>
`

  return (
    <PolioInfoPage
      title="40 Million Children to be Vaccinated Against Polio"
      path="/media-room/media-releases/611-40-million-children-to-be-vaccinated-against-polio-in-upcoming-nationwide-campaign"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
