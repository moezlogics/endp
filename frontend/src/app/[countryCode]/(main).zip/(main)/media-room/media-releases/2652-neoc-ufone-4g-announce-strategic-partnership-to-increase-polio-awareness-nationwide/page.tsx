import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "NEOC & Ufone 4G Announce Strategic Partnership to Increase Polio Awareness Nationwide",
  description: "This press release announces a strategic partnership between the National Emergency Operations Centre (NEOC) and Ufone 4G, one of Pakistan's leading telecom companies, to enhance nationwide polio awareness.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2652-neoc-ufone-4g-announce-strategic-partnership-to-increase-polio-awareness-nationwide",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release announces a strategic partnership between the National Emergency Operations Centre (NEOC) and Ufone 4G, one of Pakistan's leading telecommunications companies, to enhance nationwide polio awareness through digital and mobile communication channels.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Under the partnership, Ufone 4G will leverage its extensive subscriber base and 4G network infrastructure to deliver targeted vaccination awareness messages to parents across Pakistan. Campaigns will use SMS, mobile app notifications, and digital content to inform families about upcoming vaccination campaigns, the importance of protecting children, and how to find their nearest vaccination point.</p>
<p>The partnership is particularly significant in the context of Pakistan's growing smartphone penetration and increasing reliance on digital media for information. As traditional community mobilization channels face challenges in some areas, digital outreach offers a complementary approach to reaching parents where they spend a significant portion of their time.</p>

<h2>Public Health Impact & Operations</h2>
<p>Ufone 4G's involvement also includes employee engagement initiatives, branded communication materials in retail outlets, and social media campaigns targeting young parents and caregivers. Data analytics will be used to measure reach and refine messaging over time.</p>
<p>The NEOC welcomed the partnership as a model of private sector engagement in public health. Collaborations like this expand the programme's communication capacity without additional public expenditure, demonstrating how corporate resources and networks can be mobilized in service of national health goals. Both partners expressed commitment to working together until every child in Pakistan is protected from polio.</p>
`

  return (
    <PolioInfoPage
      title="NEOC & Ufone 4G Strategic Partnership"
      path="/media-room/media-releases/2652-neoc-ufone-4g-announce-strategic-partnership-to-increase-polio-awareness-nationwide"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
