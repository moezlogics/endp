import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Over 40 Million Children Will Be Vaccinated During Nationwide Campaign",
  description: "This press release announces a landmark nationwide vaccination campaign with an ambitious target of vaccinating over 40 million children.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/634-over-40-million-children-will-be-vaccinated-during-nationwide-campaign",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release announces a landmark nationwide vaccination campaign with an ambitious target of vaccinating over 40 million children under the age of five across all of Pakistan. The sheer scale of this operation makes it one of the largest public health mobilizations in the country's history and reflects the programme's determination to achieve maximum population immunity.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>The campaign involves the deployment of hundreds of thousands of trained vaccination workers, organized in teams of two, conducting house-to-house visits across every district, tehsil, and union council in Pakistan. Each team is assigned a specific geographic area based on detailed microplanning that maps every household.</p>
<p>Vaccines are transported and stored in a nationwide cold chain system that includes hundreds of district cold rooms, thousands of vaccine carriers, and a quality monitoring system to ensure that the oral polio vaccine maintains its efficacy throughout the distribution chain.</p>

<h2>Public Health Impact & Operations</h2>
<p>The campaign target of over 40 million children is supported by community mobilization activities that precede the campaign: announcements from mosques and schools, messages from community leaders, television and radio advertisements, and social media campaigns encouraging parental participation.</p>
<p>Transit vaccination points are established at railway stations, bus terminals, and major road checkpoints to capture children who are traveling during the campaign period and might otherwise be missed in their home areas.</p>
<p>The 40 million target reflects the programme's comprehensive ambition to protect every child in Pakistan and represents the collective effort of the government, international partners, and hundreds of thousands of dedicated health workers.</p>
`

  return (
    <PolioInfoPage
      title="Over 40 Million Children Will Be Vaccinated"
      path="/media-room/media-releases/634-over-40-million-children-will-be-vaccinated-during-nationwide-campaign"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
