import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Case Reported from Killa Abdullah",
  description: "This press release confirms the detection of a new wild poliovirus type 1 (WPV1) case in Killa Abdullah district, Balochistan province. Killa Abdullah...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2460-polio-case-reported-from-killa-abdullah",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release confirms the detection of a new wild <a href="/polioin-pakistan" class="text-blue-600 hover:underline">poliovirus</a> type 1 (WPV1) case in <a href="/essa-khan-pakistani-footballer-from-killa-abdullah-balochistan-province" class="text-blue-600 hover:underline">Killa Abdullah</a> district, Balochistan province. Killa Abdullah, located along the Pakistan-Afghanistan border, has historically been a <a href="/polioin-pakistan/high-risk-area" class="text-blue-600 hover:underline">high-risk area</a> for polio transmission due to its geographic position, population movement, and immunization coverage challenges.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>The National Institute of Health's Regional Reference Laboratory confirmed the case through environmental and clinical testing. The affected child had not received adequate doses of the oral polio vaccine (OPV), underlining the persistent challenge of reaching every child in remote and conflict-affected areas.</p>
<p>In response to this confirmed case, health authorities announced an emergency vaccination campaign targeting thousands of children in surrounding districts. Security forces were mobilized to ensure the safety of vaccination teams operating in the region.</p>

<h2>Public Health Impact & Operations</h2>
<p>This announcement also emphasizes the importance of cross-border coordination with Afghanistan, as genetic sequencing of the virus suggests transboundary transmission routes are active. Health officials reiterated the need for parents and communities in border areas to cooperate fully with vaccination teams.</p>
<p>The Killa Abdullah case is a reminder that no region in Pakistan can be considered safe until poliovirus transmission is completely interrupted across the country and the wider region.</p>
`

  return (
    <PolioInfoPage
      title="Polio Case Reported from Killa Abdullah"
      path="/media-room/media-releases/2460-polio-case-reported-from-killa-abdullah"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
