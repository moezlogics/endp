import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Imran Launches Sehat ka Insaf Campaign in KP",
  description: "This media release covers the formal launch of the \"Sehat ka Insaf\" health initiative in Khyber Pakhtunkhwa, representing a significant political commitment.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/89-imran-launches-sehat-ka-insaf-campaign-in-kp",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This media release covers the formal launch of the "Sehat ka Insaf" health initiative in Khyber Pakhtunkhwa. The campaign represented a significant political commitment to improving public health, including polio eradication, in one of Pakistan's most challenging provinces.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Khyber Pakhtunkhwa has historically borne the heaviest burden of poliovirus transmission in Pakistan, accounting for the majority of annual cases. The provincial government's formal commitment to the health agenda, symbolized by this high-profile launch, signaled a new level of political ownership over the eradication effort.</p>
<p>The Sehat ka Insaf campaign was designed to improve health service delivery across KP through better resource allocation, accountability, and community engagement. For polio specifically, it aligned with the national emergency action plan and introduced provincial-level monitoring mechanisms.</p>

<h2>Public Health Impact & Operations</h2>
<p>High-level political endorsement was significant because it elevated polio eradication from a technical programme issue to a governance priority. District commissioners and local officials received a direct mandate to support vaccination campaigns and protect health workers.</p>
<p>The launch also sent a powerful message to communities: that their elected government took polio seriously and expected them to participate in vaccination activities. This kind of political leadership has been identified by global health experts as one of the key factors in successful disease eradication campaigns.</p>
`

  return (
    <PolioInfoPage
      title="Imran Launches Sehat ka Insaf Campaign in KP"
      path="/media-room/media-releases/89-imran-launches-sehat-ka-insaf-campaign-in-kp"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
