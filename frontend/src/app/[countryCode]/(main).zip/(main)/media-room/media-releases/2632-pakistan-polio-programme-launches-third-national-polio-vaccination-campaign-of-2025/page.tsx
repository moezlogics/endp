import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Third National Polio Vaccination Campaign 2025 Pakistan – Programme Launch, Coverage Targets & Key Details | End Polio Pakistan",
  description: "This press release announces the launch of Pakistan's third national polio vaccination campaign of 2025, targeting tens of millions of children under the age of five.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/2632-pakistan-polio-programme-launches-third-national-polio-vaccination-campaign-of-2025",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release announces the launch of Pakistan's third national polio vaccination campaign of 2025, targeting tens of millions of children under the age of five across all provinces and administrative territories. Coming after the concerning case counts of early 2025, this campaign represents a critical programmatic response aimed at reversing the trend of transmission and moving Pakistan closer to eradication.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>The third national campaign of any year is typically conducted during the pre-monsoon or early monsoon period when population movement is high and the risk of poliovirus transmission through environmental pathways increases. Reaching children during this period is essential for maintaining adequate immunity levels throughout the high-risk season.</p>
<p>Hundreds of thousands of trained vaccination workers were deployed simultaneously across Pakistan for this campaign, conducting house-to-house visits in every district, tehsil, and union council. Special transit vaccination teams were positioned at railway stations, bus terminals, and major road crossings to capture children in movement.</p>

<h2>Public Health Impact & Operations</h2>
<p>The campaign was accompanied by a major communication drive including television and radio announcements, social media messaging, and direct community mobilization by trained social mobilizers and religious leaders. Areas with previous vaccine refusals received intensified outreach prior to campaign commencement.</p>
<p>Senior government officials launched the campaign publicly in their respective provinces, signaling political commitment at the highest levels. The third national campaign is a cornerstone of Pakistan's 2025 strategy to reduce cases significantly from the 2024 peak.</p>
`

  return (
    <PolioInfoPage
      title="Pakistan Polio Programme Launches Third National Polio Vaccination Campaign of 2025 – 40 Million Children Targeted"
      path="/media-room/media-releases/2632-pakistan-polio-programme-launches-third-national-polio-vaccination-campaign-of-2025"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
