import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "World Polio Day 2019: Wasim Akram Announced as Polio Ambassador",
  description: "This press release marks World Polio Day 2019 with the announcement that Wasim Akram has been appointed as a Polio Ambassador for the Pakistan Polio Eradication Programme.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/574-world-polio-day-2019-wasim-akram-announced-as-polio-ambassador",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release marks World Polio Day 2019 with the announcement that Wasim Akram, one of Pakistan's most celebrated cricketers and a global sporting icon, has been appointed as a Polio Ambassador for the Pakistan Polio Eradication Programme. This appointment represented a significant boost for the programme's public communication strategy.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Wasim Akram's appointment as ambassador leveraged his extraordinary popularity and positive image across Pakistan and beyond. As one of the greatest fast bowlers in cricket history and a beloved national figure, his endorsement of polio vaccination reached millions of Pakistanis who might not respond to conventional health messaging.</p>
<p>The ambassador role involved Wasim Akram appearing in television advertisements, social media campaigns, and public events to encourage parents to vaccinate their children. His personal testimonials about the importance of protecting children from polio resonated particularly strongly with urban and semi-urban audiences.</p>

<h2>Public Health Impact & Operations</h2>
<p>Celebrity endorsements of public health campaigns have proven effective globally. When a trusted public figure speaks about vaccination in personal, relatable terms, it can normalize vaccine-accepting behavior and counter the influence of anti-vaccination narratives.</p>
<p>World Polio Day, observed annually on October 24th, provides a global platform to highlight the progress made and the work that remains. Wasim Akram's announcement on this day amplified the programme's World Polio Day messaging and helped ensure Pakistan's eradication efforts received positive national and international media coverage.</p>
`

  return (
    <PolioInfoPage
      title="World Polio Day 2019: Wasim Akram Announced as Polio Ambassador"
      path="/media-room/media-releases/574-world-polio-day-2019-wasim-akram-announced-as-polio-ambassador"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
