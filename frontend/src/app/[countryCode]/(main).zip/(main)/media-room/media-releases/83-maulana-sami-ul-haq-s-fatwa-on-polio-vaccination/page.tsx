import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Maulana Sami ul Haq's Fatwa on Polio Vaccination",
  description: "This press release documents a landmark religious endorsement of polio vaccination by Maulana Sami ul Haq, a highly influential Islamic scholar and senator.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/83-maulana-sami-ul-haq-s-fatwa-on-polio-vaccination",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release documents a landmark religious endorsement of polio vaccination by Maulana Sami ul Haq, a highly influential Islamic scholar and senator. His fatwa declaring polio vaccination permissible and encouraged under Islamic principles was a significant milestone in addressing religious opposition to the vaccine in Pakistan.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>For years, a minority of extremist voices had claimed that the polio vaccine was haram or part of a Western conspiracy. These claims, though rejected by mainstream Islamic scholars, had created enough doubt in some communities to fuel vaccine refusals and obstruct vaccination campaigns.</p>
<p>Maulana Sami ul Haq's public endorsement carried exceptional weight precisely because of his religious authority among conservative communities in Khyber Pakhtunkhwa and the tribal areas — the regions most affected by both vaccine hesitancy and polio transmission.</p>

<h2>Public Health Impact & Operations</h2>
<p>The fatwa stated unequivocally that protecting children from disease is an Islamic duty and that the polio vaccine is safe and beneficial. It called on Muslims to cooperate fully with vaccination teams and ensure their children receive the drops.</p>
<p>This press release marks the fatwa as a powerful tool for the programme's communication strategy. Religious endorsements like this one have helped shift community attitudes in previously resistant areas, demonstrating the importance of engaging Islamic leaders as partners in the eradication effort.</p>
`

  return (
    <PolioInfoPage
      title="Maulana Sami ul Haq's Fatwa on Polio Vaccination"
      path="/media-room/media-releases/83-maulana-sami-ul-haq-s-fatwa-on-polio-vaccination"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
