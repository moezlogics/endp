import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "The Fourth National Immunisation Campaign Kicks Off to Reach More Than 40 Million Children Across Pakistan",
  description: "This press release announces the launch of Pakistan's fourth nationwide polio immunization campaign of the year, targeting over 40 million children.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/639-the-fourth-national-immunisation-campaign-kicks-off-to-reach-more-than-40-million-children-across-pakistan",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release announces the launch of Pakistan's fourth nationwide polio immunization campaign of the year, targeting over 40 million children under the age of five across the country. The campaign represents one of the largest coordinated public health operations in Pakistan's history.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Hundreds of thousands of trained vaccinators were deployed in teams to cover every household in all four provinces, Azad Kashmir, Gilgit-Baltistan, and tribal areas. The campaign used oral polio vaccine (OPV), administered as two drops directly into the child's mouth, making it one of the simplest and most effective vaccines available.</p>
<p>The campaign was accompanied by an intensive communication drive to address vaccine hesitancy and encourage parental cooperation. Community leaders, religious scholars, teachers, and local influencers played a key role in mobilizing families and dispelling myths about the vaccine.</p>

<h2>Public Health Impact & Operations</h2>
<p>Security arrangements were put in place in high-risk areas, with thousands of police officers and security personnel deployed to protect vaccination teams operating in areas affected by militancy.</p>
<p>The fourth campaign reflects the programme's year-round commitment to maintaining high immunity levels across the country. Officials acknowledged that while significant progress has been made, sustained effort through multiple campaigns per year is essential until poliovirus transmission is completely stopped.</p>
`

  return (
    <PolioInfoPage
      title="Fourth National Immunisation Campaign Kicks Off"
      path="/media-room/media-releases/639-the-fourth-national-immunisation-campaign-kicks-off-to-reach-more-than-40-million-children-across-pakistan"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
