import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Parental Refusals Adding to the National Polio Count",
  description: "This press release addresses one of the most challenging issues in Pakistan's polio eradication effort: the role of parental vaccine refusals.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/media-releases/599-parental-refusals-adding-to-the-national-polio-count",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This press release addresses one of the most challenging and sensitive issues in Pakistan's polio eradication effort: the role of parental vaccine refusals in contributing to ongoing transmission and new cases. While security challenges and geographic inaccessibility receive significant attention, persistent parental refusals represent a significant and addressable factor in Pakistan's case burden.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>Data presented in the release shows that a notable proportion of children who developed polio had parents who had previously refused vaccination for their child during one or more campaign rounds. This direct link between refusal and paralysis is presented not to blame parents but to illustrate the very real consequences of vaccine hesitancy.</p>
<p>The press release explores the common reasons behind parental refusals: religious misconceptions, fears about side effects, distrust of government health services, influence from community members who spread false information, and general skepticism about the motives behind the vaccination programme.</p>

<h2>Public Health Impact & Operations</h2>
<p>In response to each reason, the release provides clear, evidence-based information and points to the religious endorsements, scientific evidence, and track records of safety that refute the concerns. It calls on community leaders, teachers, media, and family networks to help address these misconceptions proactively.</p>
<p>The release also announces new programme measures to understand and respond to refusals more effectively, including enhanced training for vaccination teams in communication techniques for engaging resistant households and a new tracking system to follow up on previously refusing families.</p>
`

  return (
    <PolioInfoPage
      title="Parental Refusals Adding to the National Polio Count"
      path="/media-room/media-releases/599-parental-refusals-adding-to-the-national-polio-count"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
