import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Pakistan Polio Update | Media Room | End Polio Pakistan",
  description: "The Pakistan Polio Update section of the Media Room serves as the official archive for all periodic briefing documents produced by the National Emergency Operations Centre.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/pakistan-polio-update",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Pakistan Polio Update section of the Media Room serves as the official archive for all periodic briefing documents produced by the National Emergency Operations Centre. These updates range from monthly briefers to weekly newsletters and provide a comprehensive, chronological record of Pakistan's polio eradication journey.</p>

<h2>Key Objectives & Focus</h2>
<p>The documents available through this page include detailed monthly updates presenting case counts, environmental surveillance maps, campaign coverage data, and programmatic highlights. They are produced with a high standard of data accuracy and visual presentation to serve both technical and non-technical audiences.</p>
<p>You can access the monthly briefers directly, such as the <a href="/images/polio-briefer/Pakistan-Polio-Update-FEBRUARY-2019.pdf" class="text-blue-600 hover:underline">Pakistan Polio Update (February 2019)</a> PDF bulletin.</p>

<h2>Program Implementation & Next Steps</h2>
<p>For international partners, researchers, journalists, and policymakers, this archive is an invaluable resource for tracking trends over time. By comparing briefers from different periods, users can understand how the programme has evolved, where progress has been made, and where persistent challenges remain.</p>
<p>The updates section also archives special editions produced around significant events such as World Polio Day, major campaign launches, and high-level visits. These documents capture milestones and turning points in the programme's history.</p>
<p>End Polio Pakistan is committed to maintaining a complete, publicly accessible record of its work through this archive. The transparency embodied by the regular publication of these updates reflects the programme's accountability to the Pakistani public, to international donors who fund the effort, and to the global health community that monitors Pakistan's progress toward the final eradication of poliovirus.</p>
`

  return (
    <PolioInfoPage
      title="Pakistan Polio Update Archive"
      path="/media-room/pakistan-polio-update"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
