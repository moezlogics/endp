import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "End Polio Pakistan Newsletter – Monthly Programme Updates, Campaign Results & Frontline Stories | End Polio Pakistan",
  description: "The Newsletter section of End Polio Pakistan's Media Room serves as the programme's regular communication channel for stakeholders, partners, journalists, and the public.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/media-room/newsletter",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Newsletter section of End Polio Pakistan's Media Room serves as the programme's regular communication channel for stakeholders, partners, journalists, and the public. Published periodically by the National Emergency Operations Centre, the newsletter provides a curated summary of the most important developments in Pakistan's polio eradication effort.</p>

<h2>Key Objectives & Focus</h2>
<p>Each newsletter edition covers recent case confirmations and environmental surveillance findings, updates on ongoing and completed vaccination campaigns, highlights from field operations across provinces, partnership and advocacy news, and upcoming programme activities. The format is designed to be accessible and engaging for readers without deep technical backgrounds.</p>
<p>The newsletter also features human interest content — profiles of outstanding vaccination workers, community transformation stories, and accounts of programme innovations making a difference in the field. This narrative content complements the statistical data to give readers a complete picture of the programme's work.</p>

<h2>Program Implementation & Next Steps</h2>
<p>For donors and international partners, the newsletter provides a regular touchpoint demonstrating that their support is being used effectively and that progress is being made. The transparency embodied by regular public newsletter publication is a cornerstone of the programme's accountability framework.</p>
<p>The newsletter archive covers many years of programme history and serves as a valuable longitudinal record of Pakistan's eradication journey. Journalists and researchers have found the newsletter series particularly useful for understanding how the programme's priorities, strategies, and performance have evolved over time in response to changing epidemiological conditions.</p>
`

  return (
    <PolioInfoPage
      title="End Polio Pakistan Programme Newsletter"
      path="/media-room/newsletter"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
