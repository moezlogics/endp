import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "National Emergency Action Plan (NEAP) 2017–2018",
  description: "The National Emergency Action Plan for 2017–2018 was developed during a period of significant optimism in Pakistan's eradication journey. Following th...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/reports/NEAP-2017-2018-LR.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">National Emergency Action Plan</a> for 2017–2018 was developed during a period of significant optimism in Pakistan's eradication journey. Following the historic low of only eight cases in 2017, the 2017–2018 <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> was designed to build on this momentum and move decisively toward interrupting <a href="/polioin-pakistan" class="text-blue-600 hover:underline">poliovirus</a> transmission.</p>

<h2>Core Findings & Analysis</h2>
<p>The plan outlined strategies to maintain and improve upon the gains of 2017, recognizing that previous low-case periods had been followed by resurgences. Key priorities included sustaining high campaign quality throughout the year, expanding <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">environmental surveillance</a> coverage, and strengthening routine immunization to build population-level immunity between campaigns.</p>
<p>The 2017–2018 <a href="/images/reports/National-Emergency-Action-Plan-2013-(NEAP-2013).pdf" class="text-blue-600 hover:underline">NEAP</a> introduced enhanced accountability frameworks at district and union council levels, recognizing that programmatic quality ultimately depended on local execution. District review meetings, performance dashboards, and supervisory checklists were systematized across all high-risk areas.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>Community engagement was identified as a critical priority, with specific plans for working with religious scholars, community elders, and women's networks in areas where vaccine hesitancy remained a challenge. The role of female health workers was formalized and expanded in this <a href="/images/reports/NEAP.pdf" class="text-blue-600 hover:underline">NEAP</a>.</p>
<p>In retrospect, the 2017–2018 period saw Pakistan maintain relatively low case numbers before a significant resurgence in 2019. The <a href="/images/reports/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> for this period is therefore studied carefully to understand both what worked and what structural vulnerabilities remained unaddressed despite the apparent progress of 2017.</p>
`

  return (
    <PolioInfoPage
      title="National Emergency Action Plan (NEAP) 2017–2018"
      path="/images/reports/neap-2017-2018-lr-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
