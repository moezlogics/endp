import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "National Emergency Action Plan (NEAP) for Polio Eradication, 2016-2017",
  description: "The National Emergency Action Plan (NEAP) for Polio Eradication (2016-2017) outlines Pakistan’s strategic roadmap for eliminating wild poliovirus (WPV...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/reports/NEAP-2016-17-HR-090916.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">National Emergency Action Plan</a> (<a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a>) for Polio Eradication (2016-2017) outlines Pakistan’s strategic roadmap for eliminating wild <a href="/polioin-pakistan" class="text-blue-600 hover:underline">poliovirus</a> (WPV) and achieving polio-free status. Developed by the National Emergency Operations Centre (NEOC), the plan integrates comprehensive strategies to ensure every child is vaccinated and protected from the virus.</p>

<h2>Core Findings & Analysis</h2>
<p>Reaching Every Missed Child: Aims to vaccinate 25.6 million children in high-risk districts through targeted outreach, ensuring consistent immunization coverage across all communities.</p>
<p>Strengthening Routine Immunization: Focuses on integrating polio vaccination into routine health services to build sustainable immunity and reduce reliance on supplementary campaigns.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p><a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">Environmental Surveillance</a>: Utilizes sewage sampling in 38 cities to detect poliovirus circulation early, enabling rapid response to potential outbreaks.</p>
<p>Quality Assurance: Emphasizes rigorous quality standards for vaccination campaigns, including trained vaccinators, precise coverage monitoring, and prompt verification of vaccination records.</p>
<p>Innovative Delivery Models: Explores alternative vaccination approaches, such as fixed-site and mobile vaccination, to overcome logistical barriers and improve access to remote areas.</p>
<p>Achieve zero wild poliovirus cases nationwide.</p>
<p>Ensure polio-free status for Pakistan by 2018.</p>
<p>Integrate polio eradication with other public health initiatives, such as maternal and child health services.</p>
<p>The <a href="/images/reports/NEAP.pdf" class="text-blue-600 hover:underline">NEAP</a> (2016-2017) underscores the importance of sustained commitment, effective coordination among government agencies, international partners, and communities to realize the goal of a polio-free Pakistan.</p>
`

  return (
    <PolioInfoPage
      title="National Emergency Action Plan (NEAP) for Polio Eradication, 2016-2017"
      path="/images/reports/neap-2016-17-hr-090916-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
