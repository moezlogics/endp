import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "National Emergency Action Plan 2013 (NEAP 2013)",
  description: "The National Emergency Action Plan for 2013 represents one of the earliest formal emergency response frameworks developed by Pakistan to address the e...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/reports/National-Emergency-Action-Plan-2013-(NEAP-2013).pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">National Emergency Action Plan</a> for 2013 represents one of the earliest formal emergency response frameworks developed by Pakistan to address the escalating polio crisis. In 2013, Pakistan was experiencing a sharp rise in cases and was under increasing international pressure to demonstrate a credible path toward eradication.</p>

<h2>Core Findings & Analysis</h2>
<p>The <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> 2013 was developed in the context of growing security threats to vaccination teams, widespread vaccine hesitancy, and a fragmented operational structure. It outlined emergency measures to address these challenges and reorganize the programme around a more accountable, data-driven approach.</p>
<p>Key elements of the 2013 plan included the establishment of strengthened district-level accountability mechanisms, improved microplanning methodologies, enhanced community engagement strategies, and a focus on reaching children who had been consistently missed in previous campaigns.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>The plan also addressed the security crisis head-on, calling on provincial governments to provide adequate protection for vaccination teams and to engage with community and <a href="/media-room/field-stories/in-pakistan-religious-leaders-help-change-misconceptions-about-the-polio-vaccine" class="text-blue-600 hover:underline">religious leaders</a> to rebuild trust.</p>
<p>The <a href="/images/reports/NEAP.pdf" class="text-blue-600 hover:underline">NEAP</a> 2013 preceded a period of significant increase in cases, as 2014 recorded 306 cases. However, the structural reforms introduced through this plan laid important foundations for the more successful emergency responses that followed in subsequent years. It is an important document for understanding the evolution of Pakistan's <a href="/polioin-pakistan/eradication-strategy" class="text-blue-600 hover:underline">eradication strategy</a>.</p>
`

  return (
    <PolioInfoPage
      title="National Emergency Action Plan 2013 (NEAP 2013)"
      path="/images/reports/national-emergency-action-plan-2013-neap-2013-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
