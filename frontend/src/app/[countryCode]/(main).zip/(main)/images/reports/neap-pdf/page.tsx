import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "National Emergency Action Plan (NEAP) – Latest",
  description: "The National Emergency Action Plan (NEAP) represents the most current comprehensive strategic framework guiding Pakistan's polio eradication programme...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/reports/NEAP.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The <a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">National Emergency Action Plan</a> (<a href="/images/Stories/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a>) represents the most current comprehensive strategic framework guiding Pakistan's polio eradication programme. Updated annually by the National Emergency Operations Centre in collaboration with provincial governments and international partners, the <a href="/images/reports/National-Emergency-Action-Plan-2013-(NEAP-2013).pdf" class="text-blue-600 hover:underline">NEAP</a> provides the detailed operational blueprint for achieving <a href="/polioin-pakistan" class="text-blue-600 hover:underline">poliovirus</a> interruption.</p>

<h2>Core Findings & Analysis</h2>
<p>The document identifies priority geographic areas based on the latest epidemiological analysis, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">environmental surveillance</a> data, and vaccination coverage assessments. It sets annual targets for campaign coverage, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">surveillance</a> indicators, and community engagement milestones. Each province and high-risk district has specific targets and accountability mechanisms outlined in the plan.</p>
<p>Key strategies typically covered in the <a href="/images/reports/NEAP-2017-2018-LR.pdf" class="text-blue-600 hover:underline">NEAP</a> include the number and scheduling of immunization campaign rounds, environmental sampling site expansion, microplanning improvements, accountability and supervision systems, cross-border coordination with Afghanistan, and social mobilization activities.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>The <a href="/images/reports/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> also outlines resource requirements, including vaccine supplies, human resources, operational budgets, and security arrangements. This allows donor partners to align their contributions with identified needs and ensures efficient use of available resources.</p>
<p>Regular updates to the <a href="/images/reports/NEAP%20EXTENSION%202019.pdf" class="text-blue-600 hover:underline">NEAP</a> reflect the programme's adaptive management approach — learning from performance data and adjusting strategy to address emerging challenges. For anyone working in or studying Pakistan's polio eradication effort, the NEAP is the single most important strategic document and an essential reference for understanding the programme's priorities and direction.</p>
`

  return (
    <PolioInfoPage
      title="National Emergency Action Plan (NEAP) – Latest"
      path="/images/reports/neap-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
