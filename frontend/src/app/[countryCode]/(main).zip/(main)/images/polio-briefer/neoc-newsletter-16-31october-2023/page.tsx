import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "NEOC Newsletter – October 2023 (16–31)",
  description: "The NEOC Newsletter for the second half of October 2023 is a bi-weekly internal and public-facing communication produced by the National Emergency Ope...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/polio-briefer/NEOC-Newsletter-(16-31)October-2023",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The NEOC Newsletter for the second half of October 2023 is a bi-weekly internal and public-facing communication produced by the National Emergency Operations Centre to keep stakeholders informed about ongoing programme activities, emerging challenges, and key decisions.</p>

<h2>Core Findings & Analysis</h2>
<p>This newsletter covers the period from the 16th to the 31st of October 2023 — a period that includes World Polio Day on October 24th, making it a particularly significant edition. The newsletter likely contains coverage of World Polio Day events, advocacy activities, and messaging highlighting global progress and remaining challenges.</p>
<p>Regular content in NEOC newsletters includes updates on ongoing vaccination campaigns, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">environmental surveillance</a> findings, field stories from frontline workers, photographs documenting operations, and summaries of meetings and coordination sessions with provincial teams and international partners.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>The newsletter format allows the NEOC to share information that does not rise to the level of a formal press release but is nonetheless important for maintaining programme awareness and team morale. It serves as a regular touchpoint between national and provincial programme teams.</p>
<p>For external stakeholders including donors, researchers, and global health partners, the NEOC newsletter series provides an unfiltered window into the day-to-day reality of running one of the world's largest and most complex public health operations. The full newsletter archive spans many years and constitutes a rich record of Pakistan's eradication journey.</p>
`

  return (
    <PolioInfoPage
      title="NEOC Newsletter – October 2023 (16–31)"
      path="/images/polio-briefer/neoc-newsletter-16-31october-2023"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
