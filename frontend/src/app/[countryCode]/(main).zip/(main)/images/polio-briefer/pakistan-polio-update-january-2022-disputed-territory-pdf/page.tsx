import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Pakistan Polio Update (January 2022): Progress and Main Highlights",
  description: "By January 2022, Pakistan was making historic progress in its fight against polio. The country recorded one of its lowest case numbers ever, showing t...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/polio-briefer/Pakistan%20Polio%20Update%20January%202022%20disputed%20territory.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Fewer Positive <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">Sewage Samples</a>: The virus was disappearing from the environment too. Most cities reported that their sewage water tests came back completely negative for the poliovirus, meaning the active circulation of the virus had dropped drastically.</p>

<h2>Core Findings & Analysis</h2>
<p>The Quetta Block (Balochistan) and South Khyber Pakhtunkhwa (KP), where small pockets of the virus were still trying to survive.</p>
<p>Cross-Border Movement: Special attention was given to borders and transit points because a large number of families constantly move between Pakistan and Afghanistan, which can accidentally carry the virus back and forth.</p>

<h2>Action Plan & Strategic Guidelines</h2>
<p>First Sub-National Campaign of 2022: A massive campaign was launched in January to target millions of young children in the highest priority districts.</p>
<p>Closing Immunity Gaps: Teams put extra effort into finding and vaccinating "persistently missed children"—those who were absent during previous drives or whose parents had refused.</p>
<p>Stronger Vaccine Management: The programme focused on training frontline workers to handle vaccines carefully and map out every neighborhood perfectly.</p>
<p>The Main Takeaway: The January 2022 update showed that Pakistan was closer than ever to being polio-free. However, the programme warned that health teams must not relax because even a single missed child could allow the virus to rise again.</p>
`

  return (
    <PolioInfoPage
      title="Pakistan Polio Update (January 2022): Progress and Main Highlights"
      path="/images/polio-briefer/pakistan-polio-update-january-2022-disputed-territory-pdf"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "NEOC Bulletin" },
        { label: "Source", value: "National EOC" },
        { label: "Format", value: "PDF Report" },
        { label: "Data Quality", value: "Verified Data" }
      ]}
    />
  )
}
