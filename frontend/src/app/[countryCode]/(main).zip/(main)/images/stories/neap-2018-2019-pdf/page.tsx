import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "National Emergency Action Plan (NEAP) 2018–2019",
  description: "The National Emergency Action Plan (NEAP) for 2018–2019 is one of Pakistan's most comprehensive strategic documents for polio eradication. Developed b...",
  alternates: {
    canonical: "https://www.endpolio.com.pk/images/Stories/NEAP-2018-2019.pdf",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The <a href="/images/reports/National-Emergency-Action-Plan-2013-(NEAP-2013).pdf" class="text-blue-600 hover:underline">National Emergency Action Plan</a> (<a href="/images/reports/National-Emergency-Action-Plan-2013-(NEAP-2013).pdf" class="text-blue-600 hover:underline">NEAP</a>) for 2018–2019 is one of Pakistan's most comprehensive strategic documents for polio eradication. Developed by the National Emergency Operations Centre in collaboration with provincial governments and international partners, the <a href="/images/reports/NEAP.pdf" class="text-blue-600 hover:underline">NEAP</a> outlines the detailed operational framework for eliminating <a href="/polioin-pakistan" class="text-blue-600 hover:underline">poliovirus</a> during this critical period.</p>

<h2>Key Objectives & Focus</h2>
<p>The plan identifies priority geographic areas based on epidemiological data, <a href="/media-room/media-releases/2651-environmental-surveillance-results-july-2025" class="text-blue-600 hover:underline">environmental surveillance results</a>, and vaccination coverage assessments. It sets specific targets for campaign coverage, <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">surveillance</a> sensitivity, and community engagement activities.</p>
<p>Key strategies outlined in the <a href="/images/reports/NEAP-2017-2018-LR.pdf" class="text-blue-600 hover:underline">NEAP</a> include multiple national and sub-national immunization campaigns, strengthened <a href="/polioin-pakistan/surveillance" class="text-blue-600 hover:underline">environmental surveillance</a> across hundreds of sites, improved microplanning using geographic information systems, and intensified community mobilization to address vaccine refusal.</p>

<h2>Program Implementation & Next Steps</h2>
<p>The plan also addresses programmatic weaknesses identified in previous years, including accountability gaps at the district level, inadequate data quality, and security challenges in Khyber Pakhtunkhwa and Balochistan. It introduces new accountability measures and performance monitoring frameworks.</p>
<p>The 2018–2019 <a href="/images/reports/NEAP-2018-2019.pdf" class="text-blue-600 hover:underline">NEAP</a> was developed during a period when Pakistan was experiencing relatively low case numbers, and the goal was to maintain that progress and move decisively toward interrupting transmission. It remains a key reference document for understanding the evolution of Pakistan's <a href="/polioin-pakistan/eradication-strategy" class="text-blue-600 hover:underline">eradication strategy</a> and the lessons learned from previous campaign cycles.</p>
`

  return (
    <PolioInfoPage
      title="National Emergency Action Plan (NEAP) 2018–2019"
      path="/images/stories/neap-2018-2019-pdf"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
