import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Cases District Wise – 2014",
  description: "A district-wise breakdown and public health analysis of polio cases in Pakistan for the year 2014, providing historical context for eradication.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polio-cases-district-wise-2014",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The district-wise polio case data for 2014 represents one of the most alarming years in Pakistan's recent public health history. In 2014, Pakistan recorded 306 wild poliovirus cases — the highest number in the world that year and the most cases the country had seen in nearly two decades.</p>

<h2>Key Objectives & Focus</h2>
<p>This dataset breaks down the 306 confirmed WPV1 cases by district, providing a detailed geographic picture of transmission in 2014. The data reveals that the majority of cases were concentrated in Khyber Pakhtunkhwa, particularly in FATA districts including North and South Waziristan, where vaccination campaigns had been suspended due to security concerns.</p>
<p>Federally Administered Tribal Areas accounted for the largest share of cases, reflecting the catastrophic impact of years of vaccination disruptions in conflict-affected regions. Peshawar alone reported a significant number of cases, indicating widespread community transmission.</p>

<h2>Program Implementation & Next Steps</h2>
<p>The 2014 data was a turning point for Pakistan's programme. It prompted a national emergency response, the development of a new emergency action plan, increased government commitment, and significant changes to campaign strategy and accountability systems.</p>
<p>Understanding the 2014 district-wise data is essential for appreciating how far Pakistan has come since then and for identifying the underlying structural vulnerabilities that allowed such a severe outbreak to occur. It remains a critical baseline document for programme planners and researchers.</p>
`

  return (
    <PolioInfoPage
      title="Polio Cases District Wise – 2014"
      path="/polio-cases-district-wise-2014"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
