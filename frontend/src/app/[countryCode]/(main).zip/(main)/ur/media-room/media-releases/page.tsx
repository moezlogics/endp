import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Urdu Media Releases | Media Room | End Polio Pakistan",
  description: "The Urdu-language media releases section of End Polio Pakistan makes official programme communications accessible to Urdu-speaking audiences across Pakistan.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/ur/media-room/media-releases",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Urdu-language <a href="/media-room/media-releases" class="text-blue-600 hover:underline">media releases</a> section of End Polio Pakistan makes official programme communications accessible to Urdu-speaking audiences across Pakistan and the Pakistani diaspora. Since Urdu is the national language and the primary medium of communication in Pakistani mass media, providing press releases in Urdu significantly extends the programme's reach.</p>

<h2>Strategic Objectives & Announcement</h2>
<p>This section mirrors the English media releases archive but presents all content in Urdu, allowing Urdu-language journalists, broadcasters, bloggers, and community communicators to directly access and use official programme statements without the need for translation.</p>
<p>Urdu media releases include all major programme announcements: new case confirmations, campaign launches, environmental surveillance results, partnership announcements, and statements by government officials. They are written in clear, accessible Urdu that can be understood by readers across literacy levels.</p>

<h2>Public Health Impact & Operations</h2>
<p>The availability of official Urdu content also helps combat Urdu-language misinformation. When accurate information is readily available in Urdu, it provides a credible counter-narrative to false claims that circulate on Urdu-language social media platforms, WhatsApp groups, and messaging applications.</p>
<p>Reporters from Urdu-language television channels, newspapers, and digital media regularly use this section as a primary source for polio-related news. By providing accurate, formatted press releases in their working language, the programme builds stronger relationships with Urdu-language media and improves the accuracy and consistency of polio reporting across Pakistan's most widely consumed media.</p>
`

  return (
    <PolioInfoPage
      title="Urdu Media Releases Index"
      path="/ur/media-room/media-releases"
      contentHtml={content}
      metrics={[
        { label: "Document Type", value: "Press Release" },
        { label: "Publisher", value: "NEOC Pakistan" },
        { label: "Access Level", value: "Public Access" },
        { label: "Verification", value: "Official Alert" }
      ]}
    />
  )
}
