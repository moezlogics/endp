import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Dr. Rana Muhammad Safdar: Biography & Contributions",
  description: "Dr. Rana Muhammad Safdar is a highly respected public health expert and epidemiologist in Pakistan. He has played a major leadership role in the country’s fight to eliminate the poliovirus.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/rana-muhammad-safdar-coordinator-national-emergency-operations-centre-for-polio-eradication",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>Dr. Rana Muhammad Safdar is a highly respected public health expert and epidemiologist (a scientist who tracks diseases) in Pakistan. He has played a major leadership role in the country’s fight to eliminate the poliovirus.</p>

<h2>Key Objectives & Focus</h2>
<p>He completed his medical degree (MBBS) in Pakistan and went on to earn advanced degrees, including a Master of Public Health (MPH) and an M.Sc in Epidemiology. Before leading the polio programme, he gained extensive experience working with the government's health departments, specializing in tracking infectious diseases and managing health emergencies.</p>
<p>Dr. Safdar was appointed as the National Coordinator for the National Emergency Operations Centre (NEOC) for Polio Eradication. His main job was to bring together all provincial teams, international health partners, and the government to work under one unified plan. Under his management, the emergency centers became highly digitalized, making it easier to track vaccination teams and instantly see which areas were being missed.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Dr. Rana Muhammad Safdar is widely recognized as one of the key scientific minds who modernized Pakistan's polio eradication system, making the nationwide vaccination campaigns much more organized, data-driven, and effective.</p>
`

  return (
    <PolioInfoPage
      title="Dr. Rana Muhammad Safdar: Biography & Contributions"
      path="/rana-muhammad-safdar-coordinator-national-emergency-operations-centre-for-polio-eradication"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
