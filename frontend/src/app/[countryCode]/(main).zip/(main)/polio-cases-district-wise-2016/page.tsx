import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Cases District-Wise (2016)",
  description: "A district-wise breakdown and public health analysis of polio cases in Pakistan for the year 2016, providing historical context for eradication.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polio-cases-district-wise-2016",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This document presents a comprehensive breakdown of wild poliovirus (WPV) cases across different districts of Pakistan for the year 2016. The data highlights the geographical distribution of polio cases and underscores the ongoing challenges in eradicating the virus.</p>

<h2>Key Objectives & Focus</h2>
<p><strong>District-wise Case Distribution:</strong> The table lists specific districts where polio cases were reported, along with the number of confirmed cases in each district. In 2016, Pakistan recorded a total of 20 wild poliovirus cases, down from 54 in 2015.</p>
<p><strong>Geographical Hotspots:</strong> Certain districts emerged as hotspots for poliovirus circulation, particularly Khyber Agency, Bannu, and Peshawar in KP, as well as Quetta in Balochistan, indicating areas that required intensified vaccination efforts.</p>

<h2>Program Implementation & Next Steps</h2>
<p><strong>National Context:</strong> The data provides context for the overall polio situation in Pakistan during 2016, reflecting the progress made and the persistent challenges that remain.</p>
<p>This information is crucial for understanding the epidemiology of polio in Pakistan and for guiding targeted interventions to protect children from paralysis.</p>
`

  return (
    <PolioInfoPage
      title="Polio Cases District-Wise (2016)"
      path="/polio-cases-district-wise-2016"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
