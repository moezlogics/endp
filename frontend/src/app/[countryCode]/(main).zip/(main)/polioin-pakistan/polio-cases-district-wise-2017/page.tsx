import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Cases District Wise – 2017",
  description: "A district-wise breakdown and public health analysis of polio cases in Pakistan for the year 2017, providing historical context for eradication.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/polio-cases-district-wise-2017",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The district-wise polio case data for 2017 marks a period of significant progress in Pakistan's eradication journey. Pakistan recorded only eight wild poliovirus type 1 cases in 2017, a dramatic reduction from the 306 cases recorded in 2014 and among the lowest tallies the country had ever achieved.</p>

<h2>Key Objectives & Focus</h2>
<p>This dataset shows the geographic distribution of those eight cases, demonstrating that transmission had become increasingly restricted to specific high-risk areas. Cases in 2017 were largely confined to parts of Khyber Pakhtunkhwa and Federally Administered Tribal Areas, with the rest of the country showing no clinical cases.</p>
<p>The low case count in 2017 was attributed to improved campaign quality, more effective microplanning, strengthened accountability systems, better community engagement, and increased political commitment at federal and provincial levels.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Environmental surveillance, however, continued to detect poliovirus in sewage samples across a wider geographic area, indicating silent circulation beyond the confirmed clinical cases.</p>
<p>Analysts noted that while the dramatic decline was encouraging, Pakistan had experienced similar low-case periods before, only to see a resurgence. This data informed planning for subsequent years and highlighted the need to sustain high campaign quality and reach every child consistently. The 2017 district data serves as an important benchmark and a demonstration that Pakistan has the capacity to achieve very low transmission levels when the programme performs at its best.</p>
`

  return (
    <PolioInfoPage
      title="Polio Cases District Wise – 2017"
      path="/polioin-pakistan/polio-cases-district-wise-2017"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
