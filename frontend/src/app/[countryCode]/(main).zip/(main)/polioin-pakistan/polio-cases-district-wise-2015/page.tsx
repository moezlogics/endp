import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Cases District Wise – 2015",
  description: "A district-wise breakdown and public health analysis of polio cases in Pakistan for the year 2015, providing historical context for eradication.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/polio-cases-district-wise-2015",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The district-wise polio case data for 2015 marks a dramatic improvement from the catastrophic year of 2014, when Pakistan recorded 306 cases. In 2015, Pakistan's case count fell to 54 — still a challenging number but representing a significant 82 percent reduction that offered the first real evidence that the emergency response measures put in place after 2014 were having an effect.</p>

<h2>Key Objectives & Focus</h2>
<p>This dataset breaks down the 54 confirmed cases by district, revealing where transmission persisted despite the overall improvement. Cases in 2015 remained largely concentrated in Khyber Pakhtunkhwa, particularly in Peshawar and areas bordering Afghanistan, though some cases were also recorded in Balochistan.</p>
<p>The 2015 district data demonstrates the geographic clustering of transmission that is characteristic of poliovirus in Pakistan's final endemic stages. Rather than nationwide spread, the virus was increasingly confined to specific high-risk corridors and communities, which was both encouraging and a clear indicator of where programme intensity needed to be focused.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Programme analysts studying the 2015 data identified the continuing importance of addressing vaccine hesitancy in certain communities within high-risk districts, improving cross-border coordination with Afghanistan, and maintaining the political commitment that had driven the post-2014 emergency response.</p>
<p>The 2015 case data remains an important reference point in the narrative of Pakistan's eradication progress and demonstrates that dramatic improvements are achievable when the programme performs consistently at a high level.</p>
`

  return (
    <PolioInfoPage
      title="Polio Cases District Wise – 2015"
      path="/polioin-pakistan/polio-cases-district-wise-2015"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
