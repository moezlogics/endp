import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Polio Cases District Wise – 2018",
  description: "A district-wise breakdown and public health analysis of polio cases in Pakistan for the year 2018, providing historical context for eradication.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/polio-cases-district-wise-2018",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The district-wise polio case data for 2018 shows Pakistan recording 12 confirmed wild poliovirus cases — a low number that continued the trend of improvement following the emergency response initiated after 2014. The 2018 dataset provides a detailed geographic picture of the residual transmission that persisted despite the country's best efforts.</p>

<h2>Key Objectives & Focus</h2>
<p>All 12 cases were concentrated in Khyber Pakhtunkhwa and its tribal areas, confirming that while Pakistan as a whole had made tremendous progress, the transmission chain remained active in this specific region. Districts along the Pakistan-Afghanistan border continued to account for the majority of confirmed cases.</p>
<p>The 2018 district data was analyzed intensively by programme managers to understand the specific communities and transmission networks responsible for the remaining cases. This analysis informed the targeting of subsequent campaigns and the allocation of enhanced outreach resources to the most affected areas.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Environmental surveillance in 2018 continued to detect poliovirus in sewage samples from a wider geographic area than the 12 clinical cases would suggest, indicating silent circulation that was not resulting in paralysis — likely because of improved population immunity levels from years of intensive vaccination.</p>
<p>The 12 cases of 2018 were seen as a springboard for achieving zero cases, but the subsequent surge to 147 cases in 2019 demonstrated that the gains had not been fully consolidated. The 2018 district data is therefore studied carefully for what programmatic gaps were visible that, in retrospect, foreshadowed the 2019 resurgence.</p>
`

  return (
    <PolioInfoPage
      title="Polio Cases District Wise – 2018"
      path="/polioin-pakistan/polio-cases-district-wise-2018"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
