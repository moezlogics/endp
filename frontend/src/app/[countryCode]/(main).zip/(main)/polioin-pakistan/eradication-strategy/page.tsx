import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Eradication Strategy | Polio in Pakistan",
  description: "Understand the strategy for polio eradication in Pakistan. Details on vaccination campaigns, environmental surveillance, and community engagement.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/eradication-strategy",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This section outlines the strategy for polio eradication in Pakistan. It details the comprehensive approach being undertaken to eliminate poliovirus from the country and protect children from paralysis. The strategy includes key components such as vaccination campaigns, surveillance systems, and community engagement initiatives.</p>

<h2>Key Objectives & Focus</h2>
<p><strong>Vaccination Campaigns:</strong> Regular immunization drives targeting all children under the age of five to ensure widespread protection against polio.</p>
<p><strong>Surveillance Systems:</strong> Robust monitoring mechanisms to detect poliovirus circulation quickly and enable rapid response.</p>

<h2>Program Implementation & Next Steps</h2>
<p><strong>Community Engagement:</strong> Strategies to address vaccine hesitancy and build trust within communities to improve vaccination coverage.</p>
<p><strong>Partnerships:</strong> Collaboration with national and international stakeholders to coordinate efforts and leverage resources effectively.</p>
<p>This information is crucial for understanding the multifaceted approach required for polio eradication and the commitment of various stakeholders to protect children from paralysis.</p>
`

  return (
    <PolioInfoPage
      title="Eradication Strategy"
      path="/polioin-pakistan/eradication-strategy"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
