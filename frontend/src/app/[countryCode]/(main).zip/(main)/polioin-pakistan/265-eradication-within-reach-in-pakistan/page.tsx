import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Eradication Within Reach in Pakistan | Polio in Pakistan",
  description: "Read how polio eradication is closer than ever in Pakistan. Details on historical case progress, campaign endurance, and the role of communities.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/265-eradication-within-reach-in-pakistan",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>This section emphasizes that polio eradication is achievable in Pakistan through sustained efforts and community participation. It highlights the progress made in reducing polio cases and the ongoing commitment of the government and partners to eliminate the virus completely.</p>

<h2>Key Objectives & Focus</h2>
<p><strong>Progress Made:</strong> The article acknowledges the significant reduction in polio cases achieved through years of vaccination campaigns and surveillance efforts.</p>
<p><strong>Endurance and Commitment:</strong> It stresses the importance of maintaining momentum and consistency in immunization programs to reach every child.</p>

<h2>Program Implementation & Next Steps</h2>
<p><strong>Community Role:</strong> The importance of parental participation, especially mothers, in ensuring their children are vaccinated is highlighted.</p>
<p><strong>Future Outlook:</strong> The section conveys a sense of optimism that with continued dedication, Pakistan can achieve and sustain polio-free status, protecting future generations from this preventable disease.</p>
`

  return (
    <PolioInfoPage
      title="Eradication Within Reach in Pakistan"
      path="/polioin-pakistan/265-eradication-within-reach-in-pakistan"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
