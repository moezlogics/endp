import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Partners and Donors | Polio in Pakistan",
  description: "Learn about the international partners, foundations, and donor governments supporting the Pakistan Polio Eradication Programme.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/partners-and-donors",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Partners and Donors page of End Polio Pakistan acknowledges the broad coalition of international organizations, governments, foundations, and private sector partners that make Pakistan's polio eradication programme possible. The scale and complexity of the programme require resources and expertise far beyond what any single entity can provide.</p>

<h2>Key Objectives & Focus</h2>
<p>The core partners of the GPEI in Pakistan include the World Health Organization (WHO), UNICEF, the Bill & Melinda Gates Foundation, Rotary International, and the US Centers for Disease Control and Prevention (CDC). These organizations provide technical assistance, vaccines, funding, logistics support, and advocacy at national and international levels.</p>
<p>Bilateral donors including the governments of the United States, United Kingdom, Germany, Japan, Canada, and Gulf countries contribute significant financial resources to the programme through trust funds and direct support. Their investments fund vaccines, operations, surveillance infrastructure, and human resources.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Private sector partners such as telecommunications companies have contributed by sending vaccination reminders via SMS and supporting communication campaigns. Corporate entities have also participated in public awareness initiatives.</p>
<p>Religious institutions, civil society organizations, and community leaders serve as essential non-financial partners, helping build the social license necessary for vaccination teams to operate effectively in resistant communities.</p>
<p>This page reflects the programme's understanding that ending polio is a shared global responsibility and that Pakistan's success depends on sustained, coordinated support from a wide range of stakeholders both at home and abroad.</p>
`

  return (
    <PolioInfoPage
      title="Partners and Donors"
      path="/polioin-pakistan/partners-and-donors"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
