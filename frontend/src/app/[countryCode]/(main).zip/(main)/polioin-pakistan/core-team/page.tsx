import { Metadata } from "next"
import PolioInfoPage from "@modules/common/components/polio-info-page"

export const metadata: Metadata = {
  title: "Core Team | Polio in Pakistan",
  description: "Meet the dedicated leadership, public health experts, and coordinators behind the Pakistan Polio Eradication Programme at the NEOC.",
  alternates: {
    canonical: "https://www.endpolio.com.pk/polioin-pakistan/core-team",
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  const content = `<p>The Core Team page of the Pakistan Polio Eradication Programme introduces the dedicated leadership driving the country's effort to eliminate poliovirus. This team operates under the National Emergency Operations Centre (NEOC) and coordinates activities across all four provinces and special territories of Pakistan.</p>

<h2>Key Objectives & Focus</h2>
<p>The core team is composed of experienced public health professionals, epidemiologists, communication specialists, logisticians, and field coordinators. Each member plays a vital role in planning immunization campaigns, analyzing surveillance data, managing security protocols, and building community trust.</p>
<p>Leadership at the NEOC is responsible for aligning the national programme with global standards set by the Global Polio Eradication Initiative (GPEI). The team works in close partnership with UNICEF, WHO, the Bill & Melinda Gates Foundation, Rotary International, and the governments of Pakistan's provinces.</p>

<h2>Program Implementation & Next Steps</h2>
<p>Understanding the people behind the programme helps build public trust and transparency. The core team's commitment, even in the face of security threats and logistical challenges, reflects the dedication required to reach every child with life-saving polio drops.</p>
<p>This page provides insight into the organizational structure and the human strength behind Pakistan's polio eradication mission, highlighting that ending polio is not just a medical goal but a national mission.</p>
`

  return (
    <PolioInfoPage
      title="Core Team"
      path="/polioin-pakistan/core-team"
      contentHtml={content}
      metrics={[
        { label: "Topic", value: "Polio Eradication" },
        { label: "Source", value: "NEOC Pakistan" },
        { label: "Focus Area", value: "Health Education" }
      ]}
    />
  )
}
